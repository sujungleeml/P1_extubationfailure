# During this observational, noninterventional study, weaning and extubation decisions, including onset, timing, pace, and mode of weaning, were made by the medical ICU team which always included a board-certified critical care or pulmonary physician. Decisions were based on clinical judgment supplemented by application of clinical, vital sign, arterial blood gas, and physiologic criteria, including results from weaning and extubation indexes. General criteria for extubation included the following: significant improvement from the etiology of respiratory failure; appropriate respiratory drive as indicated by spontaneous respirations as the level of ventilatory support was decreased; return of adequate airway protective mechanisms; need for infrequent suctioning of airway secretions; alert mental status; stable hemodynamic profile; stable cardiac rhythm; arterial oxygen saturation <90% or PaO2>60 on fraction of inspired oxygen (FIO2)≤0.40 to 0.50; positive end-expiratory pressure≤5 cm H2O; and negative inspiratory force <—20 cm H2O. In addition, 174 of 287 (61%) patients had weaning/extubation indexes determined (at the onset of the weaning trial leading to extubation) with commonly used threshold values generally applied to weaning/extubation decision making: vital capacity (>10 mL/kg), minute ventilation (≤15 L/min), and the spontaneous rapid shallow breathing index (f/VT<100, measured according to the method of Yang and Tobin13). Weaning was usually by rapid reduction in intermittent mechanical ventilation rate or pressure support level with patients extubated after successfully tolerating a minimum of 0.5 to 2 h on minimal ventilatory support (pressure support ventilation ≤10 cm H2O; intermittent mechanical ventilation 0; positive end-expiratory pressure, ≤5 cm H2O). Customary criteria for passing a weaning trial were similar to those for assessing extubation but also included an increase in PaCO2<10 mm Hg and decrease in pH<0.10. In general, isolated criteria such as tachypnea, tachycardia, diaphoresis, agitation, or anxiety were considered to be insufficient for deeming the patient a weaning failure. Criteria for considering reintubation were similar to those used to evaluate weaning trials but also included inability to protect the airway or manage secretions and 
# PaO2<60 mm Hg or
# arterial oxygen saturation <90% on
# FIO2>0.50 to 1.0.

#랩 데이터(LABEVENTS의)는 BIDMC 정책에 따른 실측입니다. chartevents의 차트 데이터는 labevents에서 복사되므로 랩 데이터를 사용하는 것이 좋습니다. 동맥 샘플의 경우 pO2(50821) 및 PaO2(779) 값이 99% 동일하다는 것을 알 수 있습니다.

labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))

labevents
d_labitems <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_labitems"))

d_labitems %>% 
  filter(fluid == "Blood") %>% 
  filter(category == "Blood Gas") 

bloodgastest = c(50801,50802,50803,50804,50805,50806,50807,50808,50809,50810,
                 50811,50812,50813,50814,50815,50816,50817,50818,50819,50820,
                 50821,50822,50823,50824,50825,50826,50827,50828)

ext_abga <- function(bloodgastest){
  lablist <- list()
  for (i in 1:28) {
    lablist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents")) %>%
      filter(itemid %in% bloodgastest)
    if (i == 1) {
      filteredchart <- lablist[[i]]
    } else {
      filteredchart <- union(filteredchart, lablist[[i]])
    }
  }
  return(filteredchart)
} 

abga1<-ext_abga(bloodgastest)

#50801 Alveolar-arterial gradient
#50804 Calculated Total CO2
#50809 Glucose
#50810 Hematocrit,calculated
#50811 Hemoglobin
#50826 Tidal Volume
#50818 pCO2
#50827 Ventilation Rate

abga2 <- abga1 %>%
  filter(itemid == 50801) %>% 
  rename("Alveolar-arterial" = "valuenum") %>% 
  filter(!is.na(hadm_id))

abga3 <- abga1 %>%
  filter(itemid == 50804) %>% 
  rename("totalco2" = "valuenum") %>% 
  filter(!is.na(hadm_id))

abga4 <- abga1 %>%
  filter(itemid == 50809) %>% 
  rename("glucose" = "valuenum") %>% 
  filter(!is.na(hadm_id))

abga5 <- abga1 %>%
  filter(itemid == 50810) %>% 
  rename("hematocrit" = "valuenum") %>% 
  filter(!is.na(hadm_id))

abga6 <- abga1 %>%
  filter(itemid == 50811) %>% 
  rename("hemoglobin" = "valuenum") %>% 
  filter(!is.na(hadm_id))

#50818 pCO2

pco2list <- abga1 %>%
  filter(itemid == 50811) %>% 
  rename("pcO2" = "valuenum") %>% 
  filter(!is.na(hadm_id)) %>% 
  compute(dbplyr::in_schema("public","pco2list"), temporary = FALSE, overwrite = TRUE)

#50827 Ventilation Rate

abga8 <- abga1 %>%
  filter(itemid == 50827) %>% 
  rename("ventilationrate" = "value") %>% 
  filter(!is.na(hadm_id))



abga8
