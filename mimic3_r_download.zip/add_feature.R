# #앞으로만들어야할 변수
# 1. 입원당 최초 Extubation event 만 뽑기
# 2. COPD 여부(진단명)
# 3. Extubation 까지 걸린 시간 (ventilator 유지 시간)
# 4. SBP(24시간)
# 5. DBP(24시간)
# 6. Hb 수치(24시간 이내 가장 낮은 값)
# 7. Hct (24시간 이내 가장 낮은 값)
# 8. WBC (24시간 가장 최근값?)
# 9. RBC (24시간 가장 최근값?)
# 10. ANC 가장 최근값?
# 11. 동맥혈 검사 결과(ABGA)

##--입원당 최초 Extubation event 만 추출하기기
extubationtime %>% 
  count() #3901

extubation_subjected <- extubationtime %>% #2555
  group_by(hadm_id) %>% 
  arrange(hadm_id,.by_grop = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

##-- COPD 여부?


  
  
  
  
  
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > spo2time ) %>% 
  mutate(Spo2_to_Extubation_hour = day(extubation_time-spo2time)*24+hour(extubation_time-spo2time)) %>% 
  select("hadm_id","extubation_time","spo2","spo2time","Spo2_to_Extubation_hour") %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(spo2time), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  compute(dbplyr::in_schema("public","F1_SpO2"), temporary = FALSE, overwrite = TRUE)

