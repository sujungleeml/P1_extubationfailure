admissions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))
patients <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "patients"))
Age <- dplyr::tbl(conn, dbplyr::in_schema("public", "Age"))

admissions #subject_id, hadm_id, dischtime, deathtime, admission_type, ethinicity, diagnosis
patients #subject_id, gender, dob, dod, expire_flag
icustays #intime, outtime, los, subject_id, hadm_id

##AGE (CAST(adm.admittime AS DATE) - CAST(pts.dob AS DATE))  / 365.242, 0)

#require(lubridate)

#trunc((birth_date %--% x_date) / years(1))

Age = admissions %>% 
  left_join(patients, by = "subject_id") %>% 
  mutate(age = round(day(admittime - dob)/365.242,0)) %>%
  select("subject_id","hadm_id", "gender","age","dob","admittime","dischtime","expire_flag","dod","ethnicity") %>% 
  compute(dbplyr::in_schema("public","Age"), temporary = FALSE, overwrite = TRUE)

collect(Age) #58976 명

adult = Age %>% 
  filter(age>=18 & age<70)

collect(adult) #성인 = 29547 명


