install.packages("RPostgres")
install.packages("DBI")
install.packages("dbplyr")
install.packages('tidyverse')
install.packages('dbplot')
#--------------------------
install.packages("Hmisc")
install.packages("pastecs")
install.packages("psych")
install.packages("skimr")
install.packages("ggplot")
install.packages("ggplot2")
install.packages("lubridate")

library(dplyr)
library(DBI)
library(readr)
library(dbplyr)
library(stringr)
library(readr)
library(tidyverse)
library(vroom)
library(lubridate)
library(dbplot)
library(skimr)
library(ggplot2)
#library(Hmisc)
#library(pastecs)
#library(psych)
#-------connect--------------------------------------------------------------

host = "localhost"
port = "5432"
DB = "mimic3"
UserName = "postgres" 

conn <- DBI::dbConnect(
  RPostgres::Postgres(),
  dbname = DB,
  user = UserName,
  password = "Pass2020!",
  host = host,
  port = port,
  bigint = "numeric"
)

host = "160.1.17.57"
port = "5432"
DB = "mimic3"
UserName = "diana" 

conn <- DBI::dbConnect(
  RPostgres::Postgres(),
  dbname = DB,
  user = UserName,
  password = "love34",
  host = host,
  port = port,
  bigint = "numeric"
)
#---------tables------------------------------------------------------------
#admission = read_csv("c:/Data_for/ADMISSIONS.csv")
#patients = read_csv("c:/Data_for/PATIENTS.csv") 
#procedures_icd = read_csv("c:/Data_for/PROCEDURES_ICD.csv")
#procedureevents_mv = read_csv("c:/Data_for/PROCEDUREEVENTS_MV.csv")
#spo2_before_wean = read_csv("c:/Data_for/table/spo2_before_wean")
#oasis = read_csv("C:/Data_for/table/oasis")
#sapsii = read_csv("C:/Data_for/table/sapsii")

admissions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions"))
callout <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "callout"))
caregivers <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "caregivers"))
#chartevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents"))
chartevents_1 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_1"))
chartevents_2 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_2"))
chartevents_3 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_3"))
chartevents_4 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_4"))
chartevents_5 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_5"))
chartevents_6 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_6"))
chartevents_7 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_7"))
chartevents_8 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_8"))
chartevents_9 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_9"))
chartevents_10 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_10"))
chartevents_11 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_11"))
chartevents_12 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_12"))
chartevents_13 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_13"))
chartevents_14 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_14"))
chartevents_15 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_15"))
chartevents_16 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_16"))
chartevents_17 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_17"))
cptevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "cptevents"))
d_cpt <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_cpt"))
d_icd_diagnoses <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_diagnoses"))
d_icd_precedures <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_procedures"))
d_items <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_items"))
d_labitems <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_labitems"))
datetimeevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "datetimeevents"))
diagnoses_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "diagnoses_icd"))
drgcodes <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "drgcodes"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))
inputevents_cv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "inputevents_cv"))
inputevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "inputevents_mv"))
labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))
microbiologyevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "microbiologyevents"))
noteevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "noteevents"))
outputevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "outputevents"))
patients <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "patients"))
proscriptions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "prescriptions"))
procedureevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedureevents_mv"))
procedures_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedures_icd"))
services <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "services"))
transfers <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "transfers"))

