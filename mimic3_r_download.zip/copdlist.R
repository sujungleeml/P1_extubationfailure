##OPD was identified using International Classification of Diseases, Ninth Revision, Clinical Modification (ICD-9-CM) codes 
#(490, 4910, 4911, 4912, 49,120, 49,121, 49,122, 4918, 4919, 4920, 4928, 494, 4940, 4941, 496).

##참조 : https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7012221/

diagnoses_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "diagnoses_icd"))

itemids = c("490", "4910", "4911", "4912", "49120", "49121", "49122", "4918", "4919", "4920", "4928", "494", "4940", "4941", "496")

diagnoses_icd

diagnoses_icd %>% 
  filter(icd9_code %in% itemids)


ext_diagnoses <- function(itemids){
  diagnoseslist <- list()
  for (i in 1:17) {
    diagnoseslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "diagnoses_icd")) %>%
      filter(icd9_code %in% itemids)
    if (i == 1) {
      filteredchart <- diagnoseslist[[i]]
    } else {
      filteredchart <- union(filteredchart, diagnoseslist[[i]])
    }
  }
  return(filteredchart)
} 

copd1 <- ext_diagnoses(itemids)


d_icd_diagnoses <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_diagnoses"))
d_icd_diagnoses

ext_diagnoses_title <- function(itemids){
  diagnoseslist <- list()
  for (i in 1:17) {
    diagnoseslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_diagnoses")) %>%
      filter(icd9_code %in% itemids)
    if (i == 1) {
      filteredchart <- diagnoseslist[[i]]
    } else {
      filteredchart <- union(filteredchart, diagnoseslist[[i]])
    }
  }
  return(filteredchart)
} 

copd2 <- ext_diagnoses_title(itemids)




#6699
copdlist <- copd1 %>% 
  group_by(hadm_id) %>% 
  arrange(desc(icd9_code), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup() %>% 
  select("hadm_id","subject_id","icd9_code") %>% 
  left_join(copd2, by = "icd9_code") %>% 
  select("hadm_id","subject_id","icd9_code","long_title") %>% 
  compute(dbplyr::in_schema("public","copdlist"), temporary = FALSE, overwrite = TRUE)

