## ------Cuff Leak (ml)Cuff leak (ml) ?cannot use ---------------------------------------------------------
# item 에서 cuff leak present(1095) cuff leak(140), cuff Pressure-airway  둘다  yes or no 라서 쓸 수 없음

items = c(1095,140)
ext_chartevents(items) #function_chartext.R

cuffleaklist <- ext_chartevents(items) %>% 
  rename("cuffleaktime" = "charttime","cuffleak"="value") %>% 
  select("hadm_id", "cuffleaktime", "cuffleak", "valuenum") %>% 
  compute(dbplyr::in_schema("public","cuffleaklist"), temporary = FALSE, overwrite = TRUE)

cuffleaklist


