procedureevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedureevents_mv"))

intubation_time<- procedureevents_mv %>% 
  filter(itemid %in% c(224385)) %>% 
  select(hadm_id,starttime) %>% 
  rename("intubation_time" = "starttime")

extubation_time<- procedureevents_mv %>% 
  filter(itemid %in% c(227194)) %>% 
  select(hadm_id,starttime) %>% 
  rename("extubation_time" = "starttime")

extubationtime <- extubation_time %>% 
  left_join(intubation_time, by ="hadm_id") %>% 
  compute(dbplyr::in_schema("public","extubationtime"), temporary = FALSE, overwrite = TRUE)

# -- chartevents -> intubation date (itemid 418)
# -- procedureevents_mv -> intubation (itemid 224385)
# -- chartevents -> extubation date(itemid 182)
# -- precedureevents_mv -> extubation (itemid 227194)

# 
# 227194 -- "Extubation"
# , 225468 -- "Unplanned Extubation (patient-initiated)"
# , 225477 -- "Unplanned Extubation (non-patient initiated)"
