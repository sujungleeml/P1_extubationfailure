#1번째 변수 조합
#
#ventilator 연구 series1

#Age에 extubationtime 붙임임
#Severity: SAPSII
#OASIS:
#GCS
#height
#icustays #intime, outtime, los, subject_id, hadm_id 붙임
#vt
#ve
#Pimax
#RR
#SpO2
#FiO2
subject1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "subject1"))
subject2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "subject2"))


Age <- dplyr::tbl(conn, dbplyr::in_schema("public", "Age"))
SAPSII <- dplyr::tbl(conn, dbplyr::in_schema("public", "sapsii"))
OASIS <- dplyr::tbl(conn, dbplyr::in_schema("public", "oasis"))
F1_GCS <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_GCS"))
F1_HR <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_HR"))
F1_Height <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Height"))
F1_RR <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_RR"))
F1_Mbp <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Mbp"))
F1_Pimax <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Pimax"))
F1_Ve <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Ve"))
F1_Vt <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Vt"))
F1_SpO2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_SpO2"))
F1_FiO2 <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_FiO2"))

F1_InsPres <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_InsPres"))
F1_PlatPres <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_PlatPres"))
F1_ResPres  <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_ResPres"))

F1_RSBI <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_RSBI")) #n수가 너무 작음
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public", "extubationtime"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))
cuffleak <- dplyr::tbl(conn, dbplyr::in_schema("public", "cuffleak")) # 못씀씀


f1_s1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "f1_s1"))
#데이터 애매함...

# GCS : Last
# Height  


# pimax:  #mean pimax (12hr, 24 hr)
# MBP : MEAN
# HR : Mean (12hr, 24 hr)

# mean respiratory rate (12hr, 24 hr)
# SpO2  #Last Spo2
# FiO2_3 #Last FiO2
# Vt3  #mean vt3
# Ve3  #mean ve3

# RSBI2  #가장 최근 값(Last)




Extubated_adult <- Age %>% 
  left_join(subject1, by = "hadm_id") %>% 
  filter(!is.na(extubation_time))
Extubated_adult

count(Extubated_adult) # 9953 명 -> 3901 명

Extubated_adult %>% 
  compute(dbplyr::in_schema("public","Extubated_adult"), temporary = FALSE, overwrite = TRUE)

Extubated_adult
SAPSII
count(SAPSII) # 61532
count(sapsii) # 61333

sapsii <- SAPSII %>% 
  select("hadm_id","sapsii") %>% 
  distinct()

sapsii <- sapsii %>% 
  group_by(hadm_id) %>% 
  arrange(desc(sapsii), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

count(sapsii)

oasis <- OASIS %>%  #oasis, sapsis는 두개 이상일 경우 가장 큰 값 1개만 남김.
  select("hadm_id","oasis") %>% 
  group_by(hadm_id) %>% 
  arrange(desc(oasis), .by_group = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

a1 <- Extubated_adult %>% 
  left_join(oasis, by=c("hadm_id")) %>% 
  left_join(sapsii,by=c("hadm_id")) %>% 
  select("hadm_id","subject_id", "gender","age","admittime","extubation_time", "dischtime","expire_flag","dod","ethnicity","Extubation_Failure",
         "sapsii","oasis") 

count(a1) #3901
a1

gcs <- F1_GCS %>% 
  select("hadm_id","extubation_time","gcstime", "gcs") %>% 
  group_by(hadm_id, gcstime) %>% 
  arrange(desc(gcstime), .by_group = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

count(gcs) #3071

a2 <- a1 %>% 
  left_join(gcs, by = c("hadm_id","extubation_time")) %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time", "dischtime","expire_flag","dod","ethnicity","Extubation_Failure",
         "sapsii","oasis", "gcstime","gcs")

  group_by("hadm_id") %>% 
  distinct() %>% 
  ungroup()

count(a2) 
view(a2)



a3<- a2 %>% 
  left_join(F1_SpO2, by = c("hadm_id","extubation_time")) %>%
  left_join(F1_FiO2, by = c("hadm_id","extubation_time")) %>%
  select("hadm_id","subject_id","gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","Extubation_Failure",
         "sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2")

count(a3) #3538
a3


Mbp24<-F1_Mbp %>% 
  select("hadm_id", "extubation_time","mbp24") %>% 
  filter(!is.na("mbp24"))
Vt24<-F1_Vt  %>% 
  select("hadm_id", "extubation_time","vt24")%>% 
  filter(!is.na("vt24"))
Ve24<-F1_Ve %>% 
  select("hadm_id", "extubation_time","ve24")%>% 
  filter(!is.na("ve24"))
HR24<-F1_HR %>% 
  select("hadm_id", "extubation_time","hr24")%>% 
  filter(!is.na("hr24"))
RR24<-F1_RR %>% 
  select("hadm_id", "extubation_time","rr24")%>% 
  filter(!is.na("rr24"))
pimax24<-F1_Pimax %>% 
  select("hadm_id", "extubation_time","mean_pimax24")%>% 
  filter(!is.na("mean_pimax24"))

F1_Height <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Height"))

F1_SpO2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_SpO2"))
F1_FiO2 <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_FiO2"))




a24 <- a3 %>% 
  left_join(Mbp24, by = c("hadm_id","extubation_time")) %>% #3538
  left_join(Vt24, by = c("hadm_id","extubation_time")) %>%  #3538
  left_join(Ve24, by = c("hadm_id","extubation_time")) %>%  #3538
  left_join(HR24, by = c("hadm_id","extubation_time")) %>%  #3540
  left_join(RR24, by = c("hadm_id","extubation_time")) %>%   #3544
  left_join(F1_Height, by = "hadm_id") %>% #3760
  left_join(pimax24, by = c("hadm_id","extubation_time")) %>%  #5518
  rename("extubation_failure"="Extubation_Failure") %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24") %>% 
  compute(dbplyr::in_schema("public","a24"), temporary = FALSE, overwrite = TRUE)

a24f<-a24 %>% 
  select("gender","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24")
a24f %>% 
  count()#3783

a24f %>% 
  view

write.csv(a24f, "D:/projects/MIMIC3_EXTRACT_R/ventilation_dataset_4.csv") #office
write.csv(a24f, "C:/Users/sujun/Documents/Project/MIMIC3_EXTRACT/ventilation_dataset_4.csv") #home
