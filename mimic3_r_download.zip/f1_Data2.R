a24 <- dplyr::tbl(conn, dbplyr::in_schema("public", "a24"))
F1_pco2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_pco2"))
copdlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "copdlist"))

a24

data_copdadd1 <- a24 %>% 
  left_join(copdlist, "hadm_id") %>% 
  mutate(copd = if_else(!is.na(icd9_code),1,0)) %>% #diagnoses COPD YEs:1, no:0
  rename("subject_id"="subject_id.x") %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd")

data_copdadd<-data_copdadd1 %>% 
  select("gender","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd")

write.csv(data_copdadd, "D:/projects/MIMIC3_EXTRACT_R/ventilation_dataset_5.csv") #office
write.csv(data_copdadd, "C:/Users/sujun/Documents/Project/MIMIC3_EXTRACT/ventilation_dataset_5.csv") #home


pco2add1 <- data_copdadd1 %>% 
  left_join(F1_pco2, by = c("hadm_id")) %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time.x","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd","pco24")

data_pco2add<-pco2add1 %>% 
  select("gender","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd","pco24")

write.csv(data_pco2add, "C:/Users/sujun/Documents/Project/MIMIC3_EXTRACT/ventilation_dataset_6.csv") #home


pco2add1 <- data_copdadd1 %>% 
  left_join(pco2_re1, by = c("hadm_id")) %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time.x","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd","pco2")

data_pco3add<-pco2add1 %>% 
  select("hadm_id","gender","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd","pco2")

write.csv(data_pco3add, "D:/Projects/MIMIC3_EXTRACT_R/ventilation_dataset_7.csv")

pco2add1
pco2add1 %>% 
  filter(extubation_failure == 1) %>% 
  filter(ethnicity %in% "BLACK") %>% 
  count()

