#1번째 변수 조합
#
#ventilator 연구 series1

#Age에 extubationtime 붙임임
#Severity: SAPSII
#OASIS:
#GCS
#height
#icustays #intime, outtime, los, subject_id, hadm_id 붙임
#vt
#ve
#Pimax
#RR
#SpO2
#FiO2

Age <- dplyr::tbl(conn, dbplyr::in_schema("public", "Age"))
SAPSII <- dplyr::tbl(conn, dbplyr::in_schema("public", "sapsii"))
OASIS <- dplyr::tbl(conn, dbplyr::in_schema("public", "oasis"))
F1_GCS <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_GCS"))
F1_HR <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_HR"))
F1_Height <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Height"))
F1_RR <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_RR"))
F1_Mbp <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Mbp"))
F1_Pimax <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Pimax"))
F1_Ve <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Ve"))
F1_Vt <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Vt"))
F1_SpO2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_SpO2"))
F1_FiO2 <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_FiO2"))

F1_InsPres <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_InsPres"))
F1_PlatPres <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_PlatPres"))
F1_ResPres  <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_ResPres"))

F1_RSBI <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_RSBI")) #n수가 너무 작음
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public", "extubationtime"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))
cuffleak <- dplyr::tbl(conn, dbplyr::in_schema("public", "cuffleak")) # 못씀씀


f1_s1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "f1_s1"))
#데이터 애매함...

# GCS : Last
# Height  


# pimax:  #mean pimax (12hr, 24 hr)
# MBP : MEAN
# HR : Mean (12hr, 24 hr)

# mean respiratory rate (12hr, 24 hr)
# SpO2  #Last Spo2
# FiO2_3 #Last FiO2
# Vt3  #mean vt3
# Ve3  #mean ve3

# RSBI2  #가장 최근 값(Last)


Age
SAPSII
OASIS

GCS
Height_f1 

Pimax_f1 
Mbp_f1 
HR_f1 

RR_f1
SpO2_f1 
FiO2_f1 
Vt_f1
Ve_f1 
 


Extubated_adult <- Age %>% 
  left_join(extubationtime, by = "hadm_id") %>% 
  filter(!is.na(extubation_time))
Extubated_adult

count(Extubated_adult) # 9953 명 -> 3901 명

Extubated_adult %>% 
  compute(dbplyr::in_schema("public","Extubated_adult"), temporary = FALSE, overwrite = TRUE)

Extubated_adult
SAPSII
count(SAPSII) # 61532
count(sapsii) # 61333

sapsii <- SAPSII %>% 
  select("hadm_id","sapsii") %>% 
  distinct()

sapsii <- sapsii %>% 
  group_by(hadm_id) %>% 
  arrange(desc(sapsii), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

count(sapsii)

oasis <- OASIS %>%  #oasis, sapsis는 두개 이상일 경우 가장 큰 값 1개만 남김.
  select("hadm_id","oasis") %>% 
  group_by(hadm_id) %>% 
  arrange(desc(oasis), .by_group = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

a1 <- Extubated_adult %>% 
  left_join(oasis, by=c("hadm_id")) %>% 
  left_join(sapsii,by=c("hadm_id")) %>% 
  select("hadm_id","subject_id", "gender","age","admittime","extubation_time", "dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "sapsii","oasis") 


Extubated_adult
count(a1) #3901
a1

gcs <- F1_GCS %>% 
  select("hadm_id","extubation_time","gcstime", "gcs") %>% 
  group_by(hadm_id, gcstime) %>% 
  arrange(desc(gcstime), .by_group = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

count(gcs) #3071

a2 <- a1 %>% 
  left_join(gcs, by = c("hadm_id","extubation_time")) %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time", "dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "sapsii","oasis", "gcstime","gcs") %>% 
  group_by("hadm_id") %>% 
  distinct() %>% 
  ungroup() %>% 
  compute(dbplyr::in_schema("public","F1_a2"), temporary = FALSE, overwrite = TRUE)

count(a2) 
view(a2)


F1_a2<- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_a2"))
count(F1_a2) #3538


a3<- F1_a2 %>% 
  left_join(F1_SpO2, by = c("hadm_id","extubation_time")) %>%
  left_join(F1_FiO2, by = c("hadm_id","extubation_time")) %>%
  select("hadm_id","subject_id","gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2")

count(a3) #3538

a3


a24 <- a3 %>% 
  left_join(Mbp24, by = c("hadm_id","extubation_time")) %>% #3538
  left_join(Vt24, by = c("hadm_id","extubation_time")) %>%  #3538
  left_join(Ve24, by = c("hadm_id","extubation_time")) %>%  #3538
  left_join(HR24, by = c("hadm_id","extubation_time")) %>%  #3540
  left_join(RR24, by = c("hadm_id","extubation_time")) %>%   #3544
  left_join(F1_Height, by = "hadm_id") %>% #3760
  left_join(pimax24, by = c("hadm_id","extubation_time")) %>%  #5518
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24") %>% 
  compute(dbplyr::in_schema("public","a24"), temporary = FALSE, overwrite = TRUE)

a24<- dplyr::tbl(conn, dbplyr::in_schema("public", "a24"))


F1_24 <- a24 %>% 
  mutate(gender_num = if_else(gender == "M",1,0)) %>% 
  select("hadm_id","gender_num","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24") %>% 
  compute(dbplyr::in_schema("public","F1_24"), temporary = FALSE, overwrite = TRUE)

write.csv(F1_24, "C:/Users/sujung lee/Documents/R_Project/MIMIC3_EXTRACT/f1_a24.csv")

F1_24

count(a24)
view(a24)

write.csv(a24, "C:/Users/sujung lee/Documents/R_Project/MIMIC3_EXTRACT/f1_a24.csv")



a12 <- a3 %>% 
  left_join(Mbp12, by = c("hadm_id","extubation_time")) %>% #3538
  left_join(Vt12, by = c("hadm_id","extubation_time")) %>%  #3538
  left_join(Ve12, by = c("hadm_id","extubation_time")) %>%  #3538
  left_join(HR12, by = c("hadm_id","extubation_time")) %>%  #3540
  left_join(RR12, by = c("hadm_id","extubation_time")) %>%   #3544
  left_join(F1_Height, by = "hadm_id") %>% #3760
  left_join(pimax12, by = c("hadm_id","extubation_time")) %>%  #5518
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp12","vt12","ve12","hr12","rr12","mean_pimax12") %>% 
  compute(dbplyr::in_schema("public","a12"), temporary = FALSE, overwrite = TRUE)

a12<- dplyr::tbl(conn, dbplyr::in_schema("public", "a12"))
a12
count(a12)

F1_12 <- a12 %>% 
  mutate(gender_num = if_else(gender == "M",1,0)) %>% 
  select("hadm_id","gender_num","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp12","vt12","ve12","hr12","rr12","mean_pimax12") %>% 
  compute(dbplyr::in_schema("public","F1_12"), temporary = FALSE, overwrite = TRUE)


write.csv(F1_24, "C:/Users/sujung lee/Documents/R_Project/MIMIC3_EXTRACT/f1_a12.csv")

##데이터 정제#########################################################

pimax24 <- F1_Pimax %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(mean_pimax24)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_pimax24","pimaxunit")

count(pimax24)

pimax12 <- F1_Pimax %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(mean_pimax12)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_pimax12","pimaxunit")

Mbp24 <- F1_Mbp %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(mbp24)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mbp24","mbpunit")

Mbp12 <- F1_Mbp %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(mbp12)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mbp12","mbpunit")

F1_HR


HR24 <- F1_HR %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(hr24)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","hr24","hrunit")

HR12 <- F1_HR %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(hr12)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","hr12","hrunit")


RR24<- F1_RR %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(rr24)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","rr24","rrunit")

RR12<- F1_RR %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(rr12)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","rr12","rrunit")

Vt24<- F1_Vt %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(vt24)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","vt24","vtunit")

Vt12<- F1_Vt %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(vt12)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","vt12","vtunit")

Ve24<- F1_Ve %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(ve24)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","ve24","veunit")

Ve12<- F1_Ve %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(!is.na(ve12)) %>% 
  group_by("hadm_id","extubation_time") %>% 
  distinct() %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","ve12","veunit")






F1_2 <- F1_1 %>% 
  left_join(F1_Height, by = "hadm_id") %>% #키도 NA가 있음
  left_join(F1_Pimax, by = "hadm_id") %>% 
  left_join(F1_Mbp, by = "hadm_id") %>% 
  left_join(F1_HR, by = "hadm_id") %>% 
  rename("pimax12" = "mean_pimax12", "pimax24" = "mean_pimax24", "extubation_time" = "extubation_time.x") %>% 
  select("subject_id", "hadm_id", "gender","age","sapsii","oasis","gcs","height","pimax12",
         "pimax24","mbp12","mbp24","hr12","hr24","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity") %>% 
  left_join(F1_RR, by = "hadm_id") %>% 
  left_join(F1_SpO2, by = "hadm_id") %>% 
  left_join(F1_FiO2, by = "hadm_id") %>% 
  left_join(F1_Vt, by = "hadm_id") %>% 
  left_join(F1_Ve, by = "hadm_id") %>% 
  rename("extubation_time" = "extubation_time.x") %>% 
  select("subject_id", "hadm_id", "gender","age","sapsii","oasis","gcs",
         "height","pimax12","pimax24","mbp12","mbp24","hr12","hr24",
         "rr12","rr24","spo2","fio2","vt12","vt24","ve12","ve24",
         "admittime","dischtime","expire_flag","dod","ethnicity") %>% 
  filter(!is.na(vt12)) %>% #vt12 의 NA데이터가 많아서 제거함. 83150개 데이터 
  filter(!is.na(vt24)) 

count(F1_2) #185918

F1_2 %>% 
  compute(dbplyr::in_schema("public","F1_2"), temporary = FALSE, overwrite = TRUE)

F1_2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_2"))

F1_3<-F1_2 %>% 
  left_join(extubationtime, by=("hadm_id")) %>% 
  compute(dbplyr::in_schema("public","F1_3"), temporary = FALSE, overwrite = TRUE)

f1_12<-F1_3 %>% 
  select("subject_id", "hadm_id", "gender","age","sapsii","oasis","gcs",
         "rr12","spo2","fio2","vt12","ve12",
         "admittime","dischtime","expire_flag","dod","ethnicity",
         "intubation_time","extubation_time","reintubation_time","Extubation_to_Intubation_time","extubation_failure")
f1_12

f1_24<-F1_3 %>% 
  select("subject_id", "hadm_id", "gender","age","sapsii","oasis","gcs",
         "rr24","spo2","fio2","vt24","ve24",
         "admittime","dischtime","expire_flag","dod","ethnicity",
         "intubation_time","extubation_time","reintubation_time","Extubation_to_Intubation_time","extubation_failure")
f1_12

count(F1_3)
count(f1_12)
count(f1_24)

?write.csv
?write_csv
write.csv(f1_12, "C:/Users/sujung lee/Documents/R_Project/MIMIC3_EXTRACT/f1_12.csv")
write.csv(f1_24, "C:/Users/sujung lee/Documents/R_Project/MIMIC3_EXTRACT/f1_24.csv")

write_csv(f1_12)

f1_24
