#FiO2 (inspired O2 Fraction)-------------------------------------------------------------------------

# -- here we assign labels to ITEMIDs
# -- this also fuses together multiple ITEMIDs containing the same data
# -- add in some sanity checks on the values
# -- ensure FiO2 is a valid number between 21-100
# -- mistakes are rare (<100 obs out of ~100,000)
# -- there are 862 obs of valuenum == 20 - some people round down!
# -- rather than risk imputing garbage data for FiO2, we simply NULL invalid values

#labevent itemid = 50816 뽑기 여기는 값범위가 21~100 으로 잡아야 함, <20, >100 제외
#chatevent itemid = 223835 (이거는 >0 이고 <= 1 이면 * 100 을 한다.(단위위) -- improperly input data - looks like O2 flow in litres)
#chatevent itemid = 223835 (계산한 수치가 >=21, <=100 사이면, valuenum 그대로 사용한다. 나머지는 null -- unphysiological)
#chatevent itmeid 3420,3422 는 well formatted 니까 그대로 쓴다
#chatevent itemid 190  이고 valuenum이 >0.20 adn value num <1 ( -- well formatted but not in % ) 이거도 100 곱해줌
#last Fio2

extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
fio2list <- dplyr::tbl(conn, dbplyr::in_schema("public","fio2list"))

fio2list

F1_FiO2 <- fio2list %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > fio2time ) %>% 
  mutate(Fio2_to_Extubation_hour = day(extubation_time-fio2time)*24+hour(extubation_time-fio2time)) %>% 
  select("hadm_id","extubation_time","fio2","fio2time","Fio2_to_Extubation_hour") %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(fio2time), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  compute(dbplyr::in_schema("public","F1_FiO2"), temporary = FALSE, overwrite = TRUE)
