extubationtime <- dplyr::tbl(conn,dbplyr::in_schema("public", "extubationtime"))
gcslist <- dplyr::tbl(conn, dbplyr::in_schema("public", "gcslist"))
## Last GCS

F1_GCS <- gcslist %>% 
  left_join(extubationtime, by = c("hadm_id")) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > gcstime) %>%  
  select("hadm_id","extubation_time", "gcstime","gcs") %>% 
  mutate(gcs_to_Extubation_hour = day(extubation_time-gcstime)*24+hour(extubation_time-gcstime)) %>% 
  filter(gcs_to_Extubation_hour <= 24& gcs_to_Extubation_hour >= 0) %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(gcstime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  compute(dbplyr::in_schema("public","F1_GCS"), temporary = FALSE, overwrite = TRUE)

skim(F1_GCS)
