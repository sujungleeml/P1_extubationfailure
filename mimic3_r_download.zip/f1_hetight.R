

extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
Heightlist <- dplyr::tbl(conn, dbplyr::in_schema("public","Heightlist"))

#initial height
F1_Height <- Heightlist %>% 
  filter(height > 100) %>% 
  group_by(hadm_id) %>% 
  arrange(heighttime, .by_group = TRUE) %>% 
  select("hadm_id","heighttime", "height") %>% 
  compute(dbplyr::in_schema("public","F1_Height"), temporary = FALSE, overwrite = TRUE)
  
