extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
HRlist <- dplyr::tbl(conn, dbplyr::in_schema("public","HRlist"))

#mean HR

hr1 <- HRlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > hrtime ) %>% 
  mutate(HR_to_Extubation_hour = day(extubation_time-hrtime)*24+hour(extubation_time-hrtime)) %>% 
  select("hadm_id","extubation_time","hr","hrunit","HR_to_Extubation_hour") %>%
  filter(hr > 0) %>% 
  filter(hr < 300)


hr2 <- hr1 %>%
  filter(HR_to_Extubation_hour <= 24 & HR_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(hr24 = mean(hr)) %>% 
  ungroup()

hr3<- hr1 %>% 
  filter(HR_to_Extubation_hour <= 12& HR_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(hr12 = mean(hr)) %>% 
  ungroup()



F1_HR <- hr2 %>% 
  left_join(hr3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","hr12","hr24","hrunit.y") %>% 
  rename("hrunit" = "hrunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_HR"), temporary = FALSE, overwrite = TRUE)
  
F1_HR
op
