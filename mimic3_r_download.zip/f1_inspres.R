extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
InsPreslist <- dplyr::tbl(conn, dbplyr::in_schema("public","InsPreslist"))


#218,436,535,444,459,224697,224695,224696,224746,224747 -- High/Low/Peak/Mean/Neg insp force ("RespPressure")

ip1 <- InsPreslist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > insprestime ) %>% 
  mutate(Inspres_to_Extubation_hour = day(extubation_time-insprestime)*24+hour(extubation_time-insprestime)) %>% 
  select("hadm_id","extubation_time","inspres","inspresunit","Inspres_to_Extubation_hour")



ip2<- ip1 %>%
  filter(Inspres_to_Extubation_hour <= 24 & Inspres_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(inspres24 = mean(inspres)) %>% 
  ungroup()

ip3<- ip1 %>% 
  filter(Inspres_to_Extubation_hour <= 12& Inspres_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(inspres12 = mean(inspres)) %>% 
  ungroup()


F1_InsPres <- ip2 %>% 
  left_join(ip3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","inspres12","inspres24","inspresunit.y") %>% 
  rename("respresunit" = "inspresunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_InsPres"), temporary = FALSE, overwrite = TRUE)

InsPres_f1<-dplyr::tbl(conn, dbplyr::in_schema("public","F1_InsPres"))
InsPres_f1
