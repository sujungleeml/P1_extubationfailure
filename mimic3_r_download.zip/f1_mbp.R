extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
Mbplist <- dplyr::tbl(conn, dbplyr::in_schema("public","Mbplist"))

# when itemid in (456,52,6702,443,220052,220181,225312) and valuenum > 0 and valuenum < 300 then 4 -- MeanBP

mbp1 <- Mbplist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > mbptime ) %>% 
  mutate(Mbp_to_Extubation_hour = day(extubation_time-mbptime)*24+hour(extubation_time-mbptime)) %>% 
  select("hadm_id","extubation_time","mbp","mbpunit","Mbp_to_Extubation_hour") %>%
  filter(mbp > 0) %>% 
  filter(mbp < 300)


mbp2 <- mbp1 %>%
  filter(Mbp_to_Extubation_hour <= 24 & Mbp_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(mbp24 = mean(mbp)) %>% 
  ungroup()

mbp3<-mbp1 %>% 
  filter(Mbp_to_Extubation_hour <= 12& Mbp_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(mbp12 = mean(mbp)) %>% 
  ungroup()



F1_Mbp <- mbp2 %>% 
  left_join(mbp3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","mbp12","mbp24","mbpunit.y") %>% 
  rename("mbpunit" = "mbpunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_Mbp"), temporary = FALSE, overwrite = TRUE)

F1_Mbp

