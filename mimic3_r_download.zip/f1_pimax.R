#pimax -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>time  extubation 전에 시행한 것만 필요 
Pimaxlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "Pimaxlist"))

p1 <- Pimaxlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > pimaxtime ) %>% 
  select("hadm_id","extubation_time", "pimaxtime","pimax","pimaxunit") %>% 
  mutate(Pimax_to_Extubation_hour = day(extubation_time-pimaxtime)*24+hour(extubation_time-pimaxtime))  

  
p2 <- p1 %>% 
  filter(Pimax_to_Extubation_hour <= 24 & pimax > 0) %>% 
  filter(!is.na(pimax)) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_pimax24 = mean(pimax, na.rm = TRUE)) %>%
  ungroup() %>% 
  select("hadm_id","extubation_time", "mean_pimax24", "pimaxunit") %>% 
  distinct()

p2

p3<- p1 %>% 
  filter(Pimax_to_Extubation_hour <= 12) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_pimax12 = mean(pimax, na.rm = TRUE)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time", "mean_pimax12") %>% 
  distinct()

p3
  
F1_Pimax <- p2 %>% 
  left_join(p3, by = "hadm_id") %>% 
  select("hadm_id","extubation_time.y", "mean_pimax24","mean_pimax12","pimaxunit") %>% 
  rename("extubation_time" = "extubation_time.y") %>% 
  compute(dbplyr::in_schema("public","F1_Pimax"), temporary = FALSE, overwrite = TRUE)

skim(F1_Pimax)
