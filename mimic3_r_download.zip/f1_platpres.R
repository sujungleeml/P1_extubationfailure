extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
PlatPreslist <- dplyr::tbl(conn, dbplyr::in_schema("public","PlatPreslist"))


#--------543 -- PlateauPressure : 시간범위내 데이터 없음-----------------------------
#그외 데이터
# 5865,5866,224707,224709,224705,224706 -- APRV pressure
# , 60,437,505,506,686,220339,224700 -- PEEP
# , 3459 -- high pressure relief
# , 501,502,503,224702 -- PCV
# , 223,667,668,669,670,671,672 -- TCPCV
# , 224701 -- PSVlevel

pp1 <- PlatPreslist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > platprestime ) %>% 
  mutate(Platpres_to_Extubation_hour = day(extubation_time-platprestime)*24+hour(extubation_time-platprestime)) %>% 
  select("hadm_id","extubation_time","platpres","platpresunit","Platpres_to_Extubation_hour")



pp2<- pp1 %>%
  filter(Platpres_to_Extubation_hour <= 24 & Platpres_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(platpres24 = mean(platpres)) %>% 
  ungroup()

pp3<- pp1 %>% 
  filter(Platpres_to_Extubation_hour <= 12& Platpres_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(platpres12 = mean(platpres)) %>% 
  ungroup()


PlatPres_f1 <- pp2 %>% 
  left_join(pp3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","platpres12","platpres24","platpresunit.y") %>% 
  rename("platpresunit" = "platpresunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","PlatPres_f1"), temporary = FALSE, overwrite = TRUE)

PlatPres_f1
