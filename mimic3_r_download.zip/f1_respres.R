extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
ResPreslist <- dplyr::tbl(conn, dbplyr::in_schema("public","ResPreslist"))


#218,436,535,444,459,224697,224695,224696,224746,224747 -- High/Low/Peak/Mean/Neg insp force ("RespPressure")

rp1 <- ResPreslist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > resprestime ) %>% 
  mutate(Respres_to_Extubation_hour = day(extubation_time-resprestime)*24+hour(extubation_time-resprestime)) %>% 
  select("hadm_id","extubation_time","respres","respresunit","Respres_to_Extubation_hour")



rp2<- rp1 %>%
  filter(Respres_to_Extubation_hour <= 24 & Respres_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(respres24 = mean(respres)) %>% 
  ungroup()

rp3<- rp1 %>% 
  filter(Respres_to_Extubation_hour <= 12& Respres_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(respres12 = mean(respres)) %>% 
  ungroup()


F1_ResPres <- rp2 %>% 
  left_join(rp3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","respres12","respres24","respresunit.y") %>% 
  rename("respresunit" = "respresunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_ResPres"), temporary = FALSE, overwrite = TRUE)


