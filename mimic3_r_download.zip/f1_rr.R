extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
RRlist <- dplyr::tbl(conn, dbplyr::in_schema("public","RRlist"))

#mean RR valuenum > 0 and valuenum < 70 then 5 

##RR list 에서 rr 0~70 사이의 값만 골라냄, 24시간 이내 RR만 필터링 == rr1
rr1 <- RRlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > rrtime ) %>% 
  mutate(RR_to_Extubation_hour = day(extubation_time-rrtime)*24+hour(extubation_time-rrtime)) %>% 
  mutate(RR_to_Extubation_min = (day(extubation_time-rrtime)*24+hour(extubation_time-rrtime))*60+minute(extubation_time-rrtime)) %>% 
  select("hadm_id","rrtime","rr","rrunit","intubation_time","extubation_time","reintubation_time","RR_to_Extubation_hour","RR_to_Extubation_min","extubation_failure") %>%
  filter(rr > 0) %>% 
  filter(rr < 70) %>% 
  filter(RR_to_Extubation_hour <= 24 & RR_to_Extubation_hour>=0)

count(rr1)

#RR은 시간 구간별로 자를 것
#0~5분은 286개 뿐

rr30 <- rr1 %>% # 1290
  group_by(hadm_id, extubation_time) %>% 
  filter(RR_to_Extubation_min >= 20) %>% 
  filter(RR_to_Extubation_min <= 40) %>% 
  arrange(desc(rrtime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("rr30"="rr") %>% 
  compute(dbplyr::in_schema("public","rr30"), temporary = FALSE, overwrite = TRUE)

rr60 <- rr1 %>% #1338
  group_by(hadm_id, extubation_time) %>% 
  filter(RR_to_Extubation_min >= 50) %>% 
  filter(RR_to_Extubation_min <= 70) %>% 
  arrange(desc(rrtime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("rr60"="rr") %>% 
  compute(dbplyr::in_schema("public","rr60"), temporary = FALSE, overwrite = TRUE)

rr90 <- rr1 %>% #1338
  group_by(hadm_id, extubation_time) %>% 
  filter(RR_to_Extubation_min >= 80) %>% 
  filter(RR_to_Extubation_min <= 100) %>% 
  arrange(desc(rrtime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("rr90"="rr") %>% 
  compute(dbplyr::in_schema("public","rr90"), temporary = FALSE, overwrite = TRUE)

rr30
rr60
rr90

  compute(dbplyr::in_schema("public","Latest_vt"), temporary = FALSE, overwrite = TRUE)



rr2 <- rr1 %>%
  filter(RR_to_Extubation_hour <= 24 & RR_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(rr24 = mean(rr)) %>% 
  ungroup()

rr3<- rr1 %>% 
  filter(RR_to_Extubation_hour <= 12& RR_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(rr12 = mean(rr)) %>% 
  ungroup()



F1_RR <- rr2 %>% 
  left_join(rr3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","rr12","rr24","rrunit.y") %>% 
  rename("rrunit" = "rrunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_RR"), temporary = FALSE, overwrite = TRUE)



