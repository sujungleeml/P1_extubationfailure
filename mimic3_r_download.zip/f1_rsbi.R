extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
RSBIlist<- dplyr::tbl(conn, dbplyr::in_schema("public","RSBIlist"))


F1_RSBI <- RSBIlist %>%
  mutate(RSBI_to_Extubation_hour = day(extubation_time-rsbitime)*24+hour(extubation_time-rsbitime)) %>% 
  filter(!is.na(rsbi))%>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(rsbitime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>%  
  compute(dbplyr::in_schema("public","F1_RSBI"), temporary = FALSE, overwrite = TRUE)

skim(F1_RSBI)