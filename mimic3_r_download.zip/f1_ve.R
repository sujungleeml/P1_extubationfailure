#-------- Ve : exhaled minute volume 분당 호기량 1분동안 전달되는 공기의 총량 L/min ----
#=============================================================================================================================================
#Ve -> extubation time이 NA임
#: extubation 을 시행하지 않았으므로 대상자가 아님. 삭제,
#extubation_time>time  extubation 전에 시행한 것만 필요 
#시간동안 평균
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
Velist <- dplyr::tbl(conn, dbplyr::in_schema("public","Velist"))
Latest_ve <- dplyr::tbl(conn, dbplyr::in_schema("public","Latest_ve"))


count(Velist)
Velist

##Ve list 에서 24t시간 이내 Ve만 일단 뽑음

ve1 <- Velist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vetime ) %>% 
  mutate(Ve_to_Extubation_hour = day(extubation_time-vetime)*24+hour(extubation_time-vetime)) %>% 
  mutate(Ve_to_Extubation_min = (day(extubation_time-vetime)*24+hour(extubation_time-vetime))*60+minute(extubation_time-vetime)) %>% 
  select("hadm_id","vetime","ve","Veunit","intubation_time","extubation_time","reintubation_time","Ve_to_Extubation_hour","Ve_to_Extubation_min","extubation_failure") %>% 
  filter(Ve_to_Extubation_hour <= 24 & Ve_to_Extubation_hour>=0)

Latest_ve <- ve1 %>%  #3133
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(vetime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("latest_ve"="ve","veunit"="Veunit") %>% 
  compute(dbplyr::in_schema("public","Latest_ve"), temporary = FALSE, overwrite = TRUE)

Latest_ve

###---------------------------------------------
ve2 <- ve1 %>%
  filter(Ve_to_Extubation_hour <= 24 & Ve_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(ve24 = mean(ve)) %>% 
  ungroup()

ve3<- ve1 %>% 
  filter(Ve_to_Extubation_hour <= 12& Ve_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(ve12 = mean(ve)) %>% 
  ungroup()

ve3

F1_Ve <- ve3 %>% 
  left_join(ve2, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","ve12","ve24","Veunit.y") %>% 
  rename("veunit" = "Veunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_Ve"), temporary = FALSE, overwrite = TRUE)

F1_Ve
#ve는 4개밖에 값이 없음...

