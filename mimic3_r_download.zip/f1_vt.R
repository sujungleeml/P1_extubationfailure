extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
Vtlist <- dplyr::tbl(conn, dbplyr::in_schema("public","Vtlist"))
Latest_vt <-  dplyr::tbl(conn, dbplyr::in_schema("public","Latest_vt"))

Vtlist %>% 
  count()

Latest_vt <- Vtlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vttime ) %>% 
  mutate(Vt_to_Extubation_hour = day(extubation_time-vttime)*24+hour(extubation_time-vttime)) %>%
  mutate(Vt_to_Extubation_min = (day(extubation_time-vttime)*24+hour(extubation_time-vttime))*60+minute(extubation_time-vttime)) %>% 
  select("hadm_id","vttime","vt","vtunit","intubation_time","extubation_time","reintubation_time","Vt_to_Extubation_hour","Vt_to_Extubation_min","extubation_failure") %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(vttime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  filter(Vt_to_Extubation_hour<=24) %>% 
  ungroup() %>% 
  rename("latest_vt"="vt") %>% 
  compute(dbplyr::in_schema("public","Latest_vt"), temporary = FALSE, overwrite = TRUE)

Latest_vt
count(Latest_vt) #3134
Latest_vt
#vt_within5min

vt_p1<- Vtlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(vt != 0) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vttime ) %>%
  mutate(Vt_to_Extubation_hour = day(extubation_time-vttime)*24+hour(extubation_time-vttime)) %>%
  mutate(Vt_to_Extubation_min = (day(extubation_time-vttime)*24+hour(extubation_time-vttime))*60+minute(extubation_time-vttime)) %>% 
  select("hadm_id","vttime","vt","vtunit","intubation_time","extubation_time","reintubation_time","Vt_to_Extubation_hour","Vt_to_Extubation_min","extubation_failure") %>% 
  group_by(hadm_id, extubation_time) %>% 
  filter(Vt_to_Extubation_min > 0) %>%
  filter(Vt_to_Extubation_min <= 60) %>% 
  arrange(desc(vttime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("vt60"="vt") %>% 
  select("hadm_id","vttime","vt60","vtunit","extubation_time","Vt_to_Extubation_min")

vt_p1
view(vt_p1)

vt_p2<- Vtlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(vt != 0) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vttime ) %>%
  mutate(Vt_to_Extubation_hour = day(extubation_time-vttime)*24+hour(extubation_time-vttime)) %>%
  mutate(Vt_to_Extubation_min = (day(extubation_time-vttime)*24+hour(extubation_time-vttime))*60+minute(extubation_time-vttime)) %>% 
  select("hadm_id","vttime","vt","vtunit","intubation_time","extubation_time","reintubation_time","Vt_to_Extubation_hour","Vt_to_Extubation_min","extubation_failure") %>% 
  group_by(hadm_id, extubation_time) %>% 
  filter(Vt_to_Extubation_min > 60) %>%
  filter(Vt_to_Extubation_min <= 120) %>% 
  arrange(desc(vttime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("vt120"="vt") %>% 
  select("hadm_id","vttime","vt120","vtunit","extubation_time","Vt_to_Extubation_min")

vt_p2
view(vt_p2)

vt_p3<- Vtlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(vt != 0) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vttime ) %>%
  mutate(Vt_to_Extubation_hour = day(extubation_time-vttime)*24+hour(extubation_time-vttime)) %>%
  mutate(Vt_to_Extubation_min = (day(extubation_time-vttime)*24+hour(extubation_time-vttime))*60+minute(extubation_time-vttime)) %>% 
  select("hadm_id","vttime","vt","vtunit","intubation_time","extubation_time","reintubation_time","Vt_to_Extubation_hour","Vt_to_Extubation_min","extubation_failure") %>% 
  group_by(hadm_id, extubation_time) %>% 
  filter(Vt_to_Extubation_min > 0) %>%
  filter(Vt_to_Extubation_min <= 100) %>% 
  arrange(desc(vttime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup() %>% 
  rename("vt100"="vt") %>% 
  select("hadm_id","vttime","vt100","vtunit","extubation_time","Vt_to_Extubation_min")

vt_p3
view(vt_p3)
#5분 이내 측정한건 205개  
#10분 이내 429 개
#30분 이내 1537 개
#60분 이내 3550 (30분 초과 60분 이하는 2013개)
#90분 이내 5790  (30분 초과 90분 이하는 4253 개)
#30~90분은 988개 
#0~10분, 가장 마지막에 시행한 vttime 1개만 뽑아냄 => 74개
#10~30분, 가장 마지막에 시행한 vttime 1개만 뽑아냄 => 223개
#30~60분, 가장 마지막에 시행한  vttime 1개만 뽑아냄 => 483개

#0~60분은 (가장 마지막에 시행한 vttime 1개만 뽑아냄) =>716개 
#60~120분은 1100개개
  
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(vttime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>%
  filter(n==1) %>%
  ungroup()



#직전 1번째는 3136개
#직전 2번째는 3133개
#직전 3번째는 3065개
#직전 4번째는 3025개
#직전 5번째는 2909개

count(vt_before1)
  compute(dbplyr::in_schema("public","F1_SpO2"), temporary = FALSE, overwrite = TRUE)

#348250



#Vt -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>time  extubation 전에 시행한 것만 필요 
#vt 6000 근방에 작은 데이터 군집이 있음
#Vt 가 3000이 넘는 데이터는 전체 데이터 중 30개이다.
#chrome-extension://efaidnbmnnnibpcajpcglclefindmkaj/viewer.html?pdfurl=https%3A%2F%2Fwww.zoll.com%2F-%2Fmedia%2Fpublic-site%2Fproducts%2Fventilators%2F906-0731-01-05-sf_b.ashx&clen=5876109&chunk=true
#0, 과 6000은 disconnect 또는 다른 세팅값으로 보이므로 제거
#hyper vt는 10ml/kg 이상이다.
#collect 메모리로 불러옴

vt1 <- Vtlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vttime ) %>% 
  mutate(Vt_to_Extubation_hour = day(extubation_time-vttime)*24+hour(extubation_time-vttime)) %>% 
  select("hadm_id","extubation_time","vt","vtunit","Vt_to_Extubation_hour") %>%
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt != 6000) %>% 
  filter(vt <= 3000) 
  

#vt 본 결과 같은 시간(분단위)에 측정한 결과인데 값이 상이하여, 오타로 보고 해당 데이터 삭제하고 v1 생성
#같은 시간에 비교데이터는 통상 정상범위내 300-500 ml 의 값과 유사하였음.
#Tidal volume 은 기계가 한번 숨을 불어넣어주는 공기의 양 : 
#심한 폐쇄성/제한성 폐질환 환자에서 기도 압력이 증가해 있어 일회 환기량(Tidal volume, Tv) 이 제한됭 수 있음.
#보통 kg 당 7ml // 환자의 키에 의존 (몸무게가 아님), Vt가 감소할때 사강의 비율이 증가하므로 Vt가 감소하면 호흡수를 증가시킨다.
#IFR 최대 흡기 속도(Inspiratory flow rate, IFR Vt* RR = 정상성인은 60l)
# https://m.blog.naver.com/PostView.naver?isHttpsRedirect=true&blogId=congguksu&logNo=70178786032
#(10ml/kg)
#=흡기 기도 압력은 종종 높으며, 이는 폭기된 폐의 과도한 팽창 또는 "신장"의 존재를 시사합니다. 동물에서 큰 일회 호흡량을 사용한 환기는 폐 상피와 내피의 파괴, 폐 염증, 무기폐, 저산소증 및 염증 매개체의 방출을 유발했습니다
#https://www.nejm.org/doi/full/10.1056/nejm200005043421801
#급성 폐 손상 및 급성 호흡 곤란 증후군이 있는 환자의 환기 중 일회 호흡량을 낮추면 폐 손상과 염증 매개체의 방출이 감소할 수 있습니다. 16-18 그러나 이 접근법은 호흡성 산증을 유발 하고 16,17 동맥 산소화를 감소시킬 수 있습니다 19,20따라서 이러한 환자를 돌보는 데 있어 일부 목표의 우선순위를 변경해야 할 수 있습니다. 전통적인 접근 방식에서는 과도한 스트레치로부터 폐를 보호하는 것보다 동맥 이산화탄소의 정상 부분압과 pH에 도달하는 것이 더 우선시됩니다. 더 낮은 일회 호흡량을 포함하는 접근 방식에서는 그 반대가 사실입니다. 통제되지 않은 연구에서는 더 낮은 일회 호흡량을 사용하면 급성 폐 손상 및 급성 호흡 곤란 증후군 환자의 사망률을 줄일 수 있다고 제안 했지만 17 폐 보호 환기 전략에 대한 4건의 무작위 시험 결과는 상충되었습니다. 21-24 본 시험은 기계적 환기와 함께 더 낮은 일회 호흡량을 사용하는 것이 그러한 환자에서 중요한 임상 결과를 개선할 수 있는지 여부를 결정하기 위해 수행되었습니다.


vt2 <- vt1 %>%
  filter(Vt_to_Extubation_hour <= 24 & Vt_to_Extubation_hour>=0) %>%
  group_by(hadm_id,extubation_time) %>% 
  mutate(vt24 = mean(vt)) %>% 
  ungroup()

vt3<- vt1 %>% 
  filter(Vt_to_Extubation_hour <= 12& Vt_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(vt12 = mean(vt)) %>% 
  ungroup()


F1_Vt <- vt2 %>% 
  left_join(vt3, by = c("hadm_id", "extubation_time")) %>% 
  select("hadm_id","extubation_time","vt12","vt24","vtunit.y") %>% 
  rename("vtunit" = "vtunit.y") %>% 
  distinct() %>% 
  compute(dbplyr::in_schema("public","F1_Vt"), temporary = FALSE, overwrite = TRUE)

F1_Vt  %>% 
  count()

