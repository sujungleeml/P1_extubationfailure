a24 <- dplyr::tbl(conn, dbplyr::in_schema("public", "a24"))
F1_pco2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_pco2"))
copdlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "copdlist"))

###############################################################################
#                        PCO2 대체값                                  #
##############################################################################
d_labitems <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_labitems"))
labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))

d_labitems %>% 
  filter(fluid == "Blood") %>% 
  filter(category == "Blood Gas") %>% 
  view()

itemids = c("50818")
#############################itemid for ABGA###################################
#50801 Alveolar-arterial gradient
#50804 Calculated Total CO2
#50809 Glucose
#50810 Hematocrit,calculated
#50811 Hemoglobin
#50826 Tidal Volume
#50818 pCO2
#50827 Ventilation Rate
###############################################################################
pco2list <- labevents %>% 
  filter(itemid == 50818)

pco2list 
#compute(dbplyr::in_schema("public","pco2list"), temporary = FALSE, overwrite = TRUE)

pco2list %>% 
  count()
#490594

#extubation time 이 뭔가 이상하지만...
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
pco2list <-  dplyr::tbl(conn, dbplyr::in_schema("public", "pco2list"))

pco2_check <- pco2list %>% 
  left_join(extubationtime, by = c("hadm_id"), "copy" = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > charttime) %>% 
  mutate(pco2_to_Extubation_hour = day(extubation_time-charttime)*24+hour(extubation_time-charttime)) %>% 
  rename("pco2unit"="valueuom","pco2"="valuenum") %>% 
  select("hadm_id","extubation_time","pco2","pco2unit","flag","pco2_to_Extubation_hour")

pco2_check %>% 
  count()
#61820

pco2_whole <- pco2_check

pco2_24 <- pco2_check %>% 
  filter(pco2_to_Extubation_hour <= 24)

pco2_24 %>% 
  count()
#13696

anti_pco2_24<- pco2_whole %>% 
  anti_join(pco2_24, by = c("hadm_id","extubation_time"))

anti_pco2_24 %>% 
  count()
#6132

#7day= 168, 8 = 192 이전 n일 결과로 24시간내 추정?

pco2_7days<- anti_pco2_24 %>% 
  filter(pco2_to_Extubation_hour <= 192) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_7days = mean(pco2)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_7days") %>% 
  distinct()
#376

pco2_5days<- anti_pco2_24 %>% 
  filter(pco2_to_Extubation_hour <= 144) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_5days = mean(pco2)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_5days") %>% 
  distinct()
#363

pco2_3days<- anti_pco2_24 %>% 
  filter(pco2_to_Extubation_hour <= 96) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_3days = mean(pco2)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_3days") %>%
  rename("pco2"="mean_3days") %>% 
  distinct()
#325

pco2_7days
pco2_5days
pco2_3days ##이거쓰는게...

pco2_mean_compare <- pco2_7days %>% 
  left_join(pco2_5days, by=c("hadm_id","extubation_time")) %>%  
  left_join(pco2_3days, by=c("hadm_id","extubation_time"))

pco2_mean_compare %>% 
  view()

#PCO2_3days에서 데이터를 유니온하자

pco2_24 <- pco2_check %>%
  filter(pco2_to_Extubation_hour <= 24 & pco2_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(pco24 = mean(pco2)) %>% 
  ungroup() %>%
  select("hadm_id","extubation_time","pco24") %>% 
  rename("pco2"="pco24") %>%
  distinct()


pco2_24 %>% 
  count()
#2623

pco2_re1<- pco2_24 %>% 
  union(pco2_3days)

pco2_re1 %>% 
  count()
#2948

pco2_re1
#  compute(dbplyr::in_schema("public","pco2_re1"), temporary = FALSE, overwrite = TRUE)

#write.csv(pco2_re1, "D:/Projects/MIMIC3_EXTRACT_R/pco2_re1.csv") #home

###############################################################################
#                         데이터셋 만들기                                    #
###############################################################################

a24 <- dplyr::tbl(conn, dbplyr::in_schema("public", "a24"))
pco2_re1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "pco2_re1"))
copdlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "copdlist"))

a24
pco2_re1

data_copdadd1 <- a24 %>% 
  left_join(copdlist, "hadm_id") %>% 
  mutate(copd = if_else(!is.na(icd9_code),1,0)) %>% #diagnoses COPD YEs:1, no:0
  rename("subject_id"="subject_id.x") %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd")

count(data_copdadd1)

data_copdadd1
pco2_re1

pco2add1 <- data_copdadd1 %>% 
  left_join(pco2_re1, by = c("hadm_id","extubation_time")) %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd","pco2")

count(pco2add1)

data_pco2add<-pco2add1 %>% 
  select("subject_id","hadm_id","gender","age","extubation_failure",
         "height","sapsii","oasis","gcs","spo2","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24","copd","pco2")

write.csv(data_pco2add, "D:/Projects/MIMIC3_EXTRACT_R/ventilation_dataset_7.csv")




##################################################################################
#1번째 변수 조합
#
#ventilator 연구 series1

#Age에 extubationtime 붙임임
#Severity: SAPSII
#OASIS:
#GCS
#height
#icustays #intime, outtime, los, subject_id, hadm_id 붙임
#vt
#ve
#Pimax
#RR
#SpO2
#FiO2
subject1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "subject1"))
subject2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "subject2"))


Age <- dplyr::tbl(conn, dbplyr::in_schema("public", "Age"))
SAPSII <- dplyr::tbl(conn, dbplyr::in_schema("public", "sapsii"))
OASIS <- dplyr::tbl(conn, dbplyr::in_schema("public", "oasis"))
F1_GCS <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_GCS"))
F1_HR <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_HR"))
F1_Height <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Height"))
F1_RR <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_RR"))
F1_Mbp <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Mbp"))
F1_Pimax <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Pimax"))
F1_Ve <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Ve"))
F1_Vt <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Vt"))
F1_SpO2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_SpO2"))
F1_FiO2 <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_FiO2"))

F1_InsPres <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_InsPres"))
F1_PlatPres <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_PlatPres"))
F1_ResPres  <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_ResPres"))

F1_RSBI <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_RSBI")) #n수가 너무 작음
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public", "extubationtime"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))

f1_s1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "f1_s1"))
#데이터 애매함...

# GCS : Last
# Height  


# pimax:  #mean pimax (12hr, 24 hr)
# MBP : MEAN
# HR : Mean (12hr, 24 hr)

# mean respiratory rate (12hr, 24 hr)
# SpO2  #Last Spo2
# FiO2_3 #Last FiO2
# Vt3  #mean vt3
# Ve3  #mean ve3

# RSBI2  #가장 최근 값(Last)


subject1 %>% count()
#2094

subject2 %>% count()
#1712

Extubated_adult <- Age %>% 
  left_join(subject1, by = "hadm_id") %>% 
  filter(!is.na(extubation_time))
Extubated_adult

count(Extubated_adult) # 9953 명 -> 3901 명 
##2094명?


Extubated_adult
SAPSII
count(SAPSII) # 61532
count(sapsii) # 61333

sapsii <- SAPSII %>% 
  select("hadm_id","sapsii") %>% 
  distinct()

sapsii <- sapsii %>% 
  group_by(hadm_id) %>% 
  arrange(desc(sapsii), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

count(sapsii)

oasis <- OASIS %>%  #oasis, sapsis는 두개 이상일 경우 가장 큰 값 1개만 남김.
  select("hadm_id","oasis") %>% 
  group_by(hadm_id) %>% 
  arrange(desc(oasis), .by_group = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

a1 <- Extubated_adult %>% 
  left_join(oasis, by=c("hadm_id")) %>% 
  left_join(sapsii,by=c("hadm_id")) %>% 
  select("hadm_id","subject_id", "gender","age","admittime","extubation_time", "dischtime","expire_flag","dod","ethnicity","Extubation_Failure",
         "sapsii","oasis") 

count(a1) #3901 #2094
a1

gcs <- F1_GCS %>% 
  select("hadm_id","extubation_time","gcstime", "gcs") %>% 
  group_by(hadm_id, gcstime) %>% 
  arrange(desc(gcstime), .by_group = TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup()

count(gcs) #3071

a2 <- a1 %>% 
  left_join(gcs, by = c("hadm_id","extubation_time")) %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time", "dischtime","expire_flag","dod","ethnicity","Extubation_Failure",
         "sapsii","oasis", "gcstime","gcs")

a2
count(a2) #2094

group_by("hadm_id") %>% 
  distinct() %>% 
  ungroup()

count(a2) 
view(a2)



a3<- a2 %>% 
  left_join(F1_SpO2, by = c("hadm_id","extubation_time")) %>%
  left_join(F1_FiO2, by = c("hadm_id","extubation_time")) %>%
  select("hadm_id","subject_id","gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","Extubation_Failure",
         "sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2")

count(a3) #3538
a3


Mbp24<-F1_Mbp %>% 
  select("hadm_id", "extubation_time","mbp24") %>% 
  filter(!is.na("mbp24"))
Vt24<-F1_Vt  %>% 
  select("hadm_id", "extubation_time","vt24")%>% 
  filter(!is.na("vt24"))
Ve24<-F1_Ve %>% 
  select("hadm_id", "extubation_time","ve24")%>% 
  filter(!is.na("ve24"))
HR24<-F1_HR %>% 
  select("hadm_id", "extubation_time","hr24")%>% 
  filter(!is.na("hr24"))
RR24<-F1_RR %>% 
  select("hadm_id", "extubation_time","rr24")%>% 
  filter(!is.na("rr24"))
pimax24<-F1_Pimax %>% 
  select("hadm_id", "extubation_time","mean_pimax24")%>% 
  filter(!is.na("mean_pimax24"))

F1_Height <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Height"))

F1_SpO2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_SpO2"))
F1_FiO2 <-dplyr::tbl(conn, dbplyr::in_schema("public", "F1_FiO2"))



count(a24)

a24 <- a3 %>% #2094
  left_join(Mbp24, by = c("hadm_id","extubation_time")) %>% #2094
  left_join(Vt24, by = c("hadm_id","extubation_time")) %>%  #2094
  left_join(Ve24, by = c("hadm_id","extubation_time")) %>%  #2094
  left_join(HR24, by = c("hadm_id","extubation_time")) %>% #2094
  left_join(RR24, by = c("hadm_id","extubation_time")) %>% #2094
  left_join(F1_Height, by = "hadm_id") %>%   #2279
  left_join(pimax24, by = c("hadm_id","extubation_time")) %>%  #3783
  rename("extubation_failure"="Extubation_Failure") %>% 
  select("subject_id", "hadm_id", "gender","age","admittime","extubation_time","dischtime","expire_flag","dod","ethnicity","extubation_failure",
         "height","sapsii","oasis","gcstime","gcs","spo2time","spo2","fio2time","fio2",
         "mbp24","vt24","ve24","hr24","rr24","mean_pimax24")

a24 %>% 
  compute(dbplyr::in_schema("public","a24"), temporary = FALSE, overwrite = TRUE)


