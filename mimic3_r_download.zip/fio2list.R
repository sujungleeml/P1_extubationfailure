#FiO2 (inspired O2 Fraction)-------------------------------------------------------------------------

  # -- here we assign labels to ITEMIDs
  # -- this also fuses together multiple ITEMIDs containing the same data
  # -- add in some sanity checks on the values
  # -- ensure FiO2 is a valid number between 21-100
  # -- mistakes are rare (<100 obs out of ~100,000)
  # -- there are 862 obs of valuenum == 20 - some people round down!
  # -- rather than risk imputing garbage data for FiO2, we simply NULL invalid values
 
#labevent itemid = 50816 뽑기 여기는 값범위가 21~100 으로 잡아야 함, <20, >100 제외
#chatevent itemid = 223835 (이거는 >0 이고 <= 1 이면 * 100 을 한다.(단위위) -- improperly input data - looks like O2 flow in litres)
#chatevent itemid = 223835 (계산한 수치가 >=21, <=100 사이면, valuenum 그대로 사용한다. 나머지는 null -- unphysiological)
#chatevent itmeid 3420,3422 는 well formatted 니까 그대로 쓴다
#chatevent itemid 190  이고 valuenum이 >0.20 adn value num <1 ( -- well formatted but not in % ) 이거도 100 곱해줌


labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))
fio2_lab <- labevents %>% 
  filter(itemid == 50816) %>% 
  filter(valuenum >20 & valuenum <= 100) %>% 
  compute(dbplyr::in_schema("public","fio2_lab"), temporary = FALSE, overwrite = TRUE)

##chartevents
items = c(223835,3420,3422,190)
fio2_char <- ext_chartevents(items) %>% 
  compute(dbplyr::in_schema("public","fio2_char"), temporary = FALSE, overwrite = TRUE)

#union

fio2_lab <- dplyr::tbl(conn, dbplyr::in_schema("public", "fio2_lab"))
fio2_char <- dplyr::tbl(conn, dbplyr::in_schema("public", "fio2_char"))

# fio2_char %>% 
#   filter(itemid == 223835) %>% 
#   filter(valuenum >0 & valuenum <= 1)
# 
# fio2_char %>% 
#   filter(itemid == 190) %>% 
#   filter(valuenum > 0.2 & valuenum < 1)


f1<- fio2_char %>% 
  mutate(fio2 = if_else(itemid %in% 223835 & valuenum >0 & valuenum <= 1, valuenum * 100, if_else(itemid %in% 190 & valuenum >0.2 &valuenum <1, valuenum *100, valuenum ))) %>% 
  filter(fio2 > 20 & fio2 <= 100)

count(f1)

f2<- fio2_lab %>% 
  rename("fio2" = "valuenum")

count(f2)

count(f3)

fio2list <- union(f1,f2) %>% 
  rename("fio2time" = "charttime") %>% 
  select("hadm_id","fio2time","fio2") %>% 
  compute(dbplyr::in_schema("public","fio2list"), temporary = FALSE, overwrite = TRUE)
