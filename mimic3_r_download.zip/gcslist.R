# gcschartevnetslist <- list()
# 
# for (i in 1:17) {
#   gcschartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
#     filter(itemid %in% c(723, 454, 184, 223900, 223901, 22073))
#   if (i == 1) {
#     gcslist <- gcschartevnetslist[[i]]
#   } else {
#     gcslist <- union(gcslist, gcschartevnetslist[[i]])
#   }
# }

items = c(723, 454, 184, 223900, 223901, 22073)
ext_chartevents(items)

gcslist <- ext_chartevents(items) %>% 
  rename("gcstime" = "charttime","gcs"="valuenum") %>% 
  select("hadm_id", "gcstime", "gcs") %>% 
  compute(dbplyr::in_schema("public","gcslist"), temporary = FALSE, overwrite = TRUE)
