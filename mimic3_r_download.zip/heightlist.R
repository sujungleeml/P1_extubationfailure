# -- convert inches to centimetres
# when itemid in (920, 1394, 4187, 3486) valuenum * 2.54
# (226730,920, 1394, 4187, 3486,3485,4188) -- height
# >100

#height

items = c(226730,920, 1394, 4187, 3486,3485,4188) #height
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

Heightlist <- ext_chartevents(items) %>% 
  mutate(height = if_else(itemid %in% c(920, 1394, 4187, 3486),(valuenum * 2.54),valuenum)) %>% #inch -> cm 으로 변경경
  rename("heighttime" = "charttime","heightunit"="valueuom") %>% 
  select("hadm_id","itemid", "heighttime", "height","heightunit") %>% 
  compute(dbplyr::in_schema("public","Heightlist"), temporary = FALSE, overwrite = TRUE)
  

