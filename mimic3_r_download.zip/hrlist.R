
# # when itemid in (211,220045) and valuenum > 0 and valuenum < 300 then 1 -- HeartRate-----------------------------

items = c(211,220045)
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

HRlist <- ext_chartevents(items) %>% 
  rename("hrtime" = "charttime","hr"="valuenum","hrunit"="valueuom") %>% 
  select("hadm_id", "hrtime", "hr","hrunit") %>% 
  compute(dbplyr::in_schema("public","HRlist"), temporary = FALSE, overwrite = TRUE)

HRlist
