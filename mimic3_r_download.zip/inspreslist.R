
#--------221,1,1211,1655,2000,226873,224738,224419,224750,227187 -- Insp pressure-----------------------------

items = c(221,1,1211,1655,2000,226873,224738,224419,224750,227187)
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

InsPreslist <- ext_chartevents(items) %>% 
  rename("insprestime" = "charttime","inspres"="valuenum","inspresunit"="valueuom") %>% 
  select("hadm_id", "insprestime", "inspres","inspresunit")
#  compute(dbplyr::in_schema("public","InsPreslist"), temporary = FALSE, overwrite = TRUE)

InsPreslist

