# when itemid in (456,52,6702,443,220052,220181,225312) and valuenum > 0 and valuenum < 300 then 4 -- MeanBP

items = c(456,52,6702,443,220052,220181,225312)
ext_chartevents(items)

Mbplist <- ext_chartevents(items) %>% 
  rename("mbptime" = "charttime","mbp"="valuenum","mbpunit"="valueuom") %>% 
  select("hadm_id", "mbptime", "mbp","mbpunit") %>% 
  compute(dbplyr::in_schema("public","Mbplist"), temporary = FALSE, overwrite = TRUE)

Mbplist

