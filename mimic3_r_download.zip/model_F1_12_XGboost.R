#XGboost

install.packages("mlr3")
install.packages("tidymodels")
install.packages("xgboost")
install.packages("caret")

library(caret)
library("mlr3")
library("xgboost")
#-------------------------
F1_24
F1_12


f2 = read.csv("f1_a12.csv")
str(f2)

index = createDataPartition(f2$extubation_failure, p=0.7, list=FALSE)

f2_train = f2[index,]
f2_test = f2[-index,]

str(f2_train)
str(f2_test)

bstSparse <- xgboost(data = train$data, 
                     label = train$label, 
                     max.depth = 2, 
                     eta = 1,
                     nthread = 2,
                     nrounds = 2,
                     objective = "binary:logistic")

train.data = f2_train[,-5]
y = f2_train$extubation_failure
test.data = f2_test[,-5]
y_test = as.factor(f2_test$extubation_failure)

table(f2_test$extubation_failure)

dtrain <- xgb.DMatrix(data = as.matrix(train.data), label = y, missing=NA)
dtest = xgb.DMatrix(data = as.matrix(test.data), label= y_test, missing=NA)

xgb_grid = expand.grid(
  nrounds = 5,
  eta = c(0.1, 0.05, 0.01),
  max_depth = c(2, 3, 4, 5, 6),
  gamma = c(0.1,0,10),
  colsample_bytree=1,
  min_child_weight=c(1, 2, 3, 4 ,5),
  subsample=1
)

xgb_caret <- train(x=train.data, y=y, method='xgbTree', tuneGrid=xgb_grid) 
xgb_caret$bestTune


default_param<-list(
  objective = "reg:squarederror",
  booster = "gbtree",
  eta=0.1, #default = 0.3
  gamma=0,
  max_depth=6, #default=6
  min_child_weight=2, #default=1
  subsample=1,
  colsample_bytree=1
)
xgbcv <- xgb.cv( params = default_param, data = dtrain, 
                 nrounds = 100, nfold = 5, showsd = T, stratified = T, 
                 print_every_n = 40, early_stopping_rounds = 10, maximize = F)

cvplot = function(xgbcv)
{
  eval.log = xgbcv$evaluation_log
  std=names(eval.log[,2]) %>% gsub('train_','',.) %>% gsub('_mean','',.)
  data.frame(error=c(unlist(eval.log[,2]), unlist(eval.log[,4])), 
             class=c(rep('train',nrow(eval.log)),
                     rep('test',nrow(eval.log))),
             nround=rep(1:nrow(eval.log),2)
  ) %>%
    ggplot(aes(nround,error,col=class))+
    geom_point(alpha=0.2)+
    geom_smooth(alpha=0.4,se=F)+
    theme_bw()+
    ggtitle("XGBoost Cross-validation Visualization_1", 
            subtitle= paste0('fold : ', length(xgbcv$folds),
                             ' iteration : ', xgbcv$niter)
    )+ylab(std)+theme(axis.title=element_text(size=11))
}
cvplot(xgbcv)

xgb_mod <- xgb.train(data = dtrain, params=default_param, nrounds = 100)
XGB_rpred1 <- predict(xgb_mod, dtest)
hist(XGB_rpred1)
y_pred = ifelse(XGB_rpred1 > 0.5, 1,0)
y_pred = as.factor(y_pred)
confusionMatrix(y_pred, y_test)

xgb.importance(feature_names = NULL, model = xgb_mod, data = dtrain, label = NULL, target = y)

