#Logistic regression
install.packages("tidymodels")
library("tidymodels")



f1 = read.csv("f1_a24.csv")

f1

fr = f1[,-13]
fr
glm(fr)


logistic_reg(
  mode = "classification",
  engine = "glm",
  penalty = NULL,
  mixture = NULL
)

fit.model_spec()

