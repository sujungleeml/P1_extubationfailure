install.packages("RPostgres")
install.packages("DBI")
install.packages("dbplyr")
install.packages('tidyverse')
install.packages('dbplot')
#--------------------------
install.packages("Hmisc")
install.packages("pastecs")
install.packages("psych")
install.packages("skimr")
install.packages("ggplot")
install.packages("ggplot2")

library(dplyr)
library(DBI)
library(readr)
library(dbplyr)
library(stringr)
library(readr)
library(tidyverse)
library(vroom)
library(lubridate)
library(dbplot)
library(skimr)
library(ggplot2)
#library(Hmisc)
#library(pastecs)
#library(psych)
#-------connect--------------------------------------------------------------

host = "160.1.17.57"
port = "5432"
DB = "mimic3"
UserName = "diana" 

conn <- DBI::dbConnect(
  RPostgres::Postgres(),
  dbname = DB,
  user = UserName,
  password = "love34",
  host = host,
  port = port,
  bigint = "numeric"
)
#---------tables------------------------------------------------------------
#admission = read_csv("c:/Data_for/ADMISSIONS.csv")
#patients = read_csv("c:/Data_for/PATIENTS.csv") 
#procedures_icd = read_csv("c:/Data_for/PROCEDURES_ICD.csv")
#procedureevents_mv = read_csv("c:/Data_for/PROCEDUREEVENTS_MV.csv")
#spo2_before_wean = read_csv("c:/Data_for/table/spo2_before_wean")
#oasis = read_csv("C:/Data_for/table/oasis")
#sapsii = read_csv("C:/Data_for/table/sapsii")

admissions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions"))
callout <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "callout"))
caregivers <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "caregivers"))
#chartevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents"))
chartevents_1 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_1"))
chartevents_2 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_2"))
chartevents_3 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_3"))
chartevents_4 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_4"))
chartevents_5 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_5"))
chartevents_6 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_6"))
chartevents_7 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_7"))
chartevents_8 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_8"))
chartevents_9 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_9"))
chartevents_10 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_10"))
chartevents_11 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_11"))
chartevents_12 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_12"))
chartevents_13 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_13"))
chartevents_14 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_14"))
chartevents_15 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_15"))
chartevents_16 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_16"))
chartevents_17 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_17"))
cptevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "cptevents"))
d_cpt <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_cpt"))
d_icd_diagnoses <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_diagnoses"))
d_icd_precedures <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_procedures"))
d_items <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_items"))
d_labitems <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_labitems"))
datetimeevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "datetimeevents"))
diagnoses_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "diagnoses_icd"))
drgcodes <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "drgcodes"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))
inputevents_cv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "inputevents_cv"))
inputevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "inputevents_mv"))
labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))
microbiologyevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "microbiologyevents"))
noteevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "noteevents"))
outputevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "outputevents"))
patients <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "patients"))
prescriptions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "prescriptions"))
procedureevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedureevents_mv"))
procedures_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedures_icd"))
services <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "services"))
transfers <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "transfers"))
#------------------------------------------------------------------------------------------

reintubation_time <- dplyr::tbl(conn, dbplyr::in_schema("public", "reintubation_time"))
add_extubation_time <- dplyr::tbl(conn, dbplyr::in_schema("public", "add_extubation_time"))
oasis <- dplyr::tbl(conn, dbplyr::in_schema("public","oasis"))
sapsii <- dplyr::tbl(conn, dbplyr::in_schema("public","sapsii"))
spo2_before_wean <- dplyr::tbl(conn, dbplyr::in_schema("public","spo2_before_wean"))
resp_rate <- dplyr::tbl(conn, dbplyr::in_schema("public", "resp_rate"))

#1차 셀렉션
selcuffleaklist <-dplyr::tbl(conn, dbplyr::in_schema("public", "selcuffleaklist"))
selgcslist <- dplyr::tbl(conn, dbplyr::in_schema("public", "selgcslist"))
selRSBIlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "selRSBIlist"))
selpimaxlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "selpimaxlist"))
selVelist <- dplyr::tbl(conn, dbplyr::in_schema("public", "selVelist"))
selvtlist <- dplyr::tbl(conn, dbplyr::in_schema("public", "selvtlist"))
spo2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "spo2"))
rr

#2차 셀렉션-- EXTUBATION TIME을 붙여서 EXTUBATION TIME 이후의 이벤트를 없애고, 해당 PROCEDURE 에서
#eXTUBATION 까지 걸리는 시간을 구하여  (Procedure)_to_Extubation_time 으로 정의함.
#RSBI2를 제외하고, RR3, SpO2_3, gcs3, pimax3, Vt3, Ve3 는 24시간 이내 자료만 추출하였음. RSBI는 24시간내 할시 데이터량이 급감
#각 24시간내 자료는 환자마다 빈도가 다름 가장 최근값? 평균? 등 어떤 자료로 분석할 것인지 논의 필요함 ????????????????????
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public", "extubationtime"))
RR2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "RR2"))
SpO2_2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "SpO2_2"))
gcs2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "gcs2"))
RSBI2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "RSBI2"))
pimax2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "pimax2"))
Vt2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "Vt2"))
Ve2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "Ve2"))

#3차 selection
RR3 <- dplyr::tbl(conn, dbplyr::in_schema("public", "RR3")) #mean respiratory rate
SpO2_3 <- dplyr::tbl(conn, dbplyr::in_schema("public", "SpO2_2")) #Last Spo2
gcs3 <- dplyr::tbl(conn, dbplyr::in_schema("public", "gcs2")) # 중복값 있을 시 Last gcs 로 선택
RSBI2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "RSBI2")) #가장 최근 값(Last)
pimax3 <- dplyr::tbl(conn, dbplyr::in_schema("public", "pimax2")) #mean pimax
Vt3 <- dplyr::tbl(conn, dbplyr::in_schema("public", "Vt2")) #mean vt3
Ve3 <- dplyr::tbl(conn, dbplyr::in_schema("public", "Ve2")) #mean ve3


#Extubation 후 몇시간내 intubation 시행했을 때 Extubation Failure 로 정의할 것인가??
reintubation_time <- dplyr::tbl(conn, dbplyr::in_schema("public", "reintubation_time"))
#Rewritten 제거, 
count(reintubation_time)
count(reintubation_time %>% 
  filter(reintubation_time <=72))


#나이 걸러내기


#############################chartevents 에서 데이터 추출하기 ###############################################
#1차 셀렉션#################################################################################################
##-----RR은 구해놨음 ---------------------------------------------------------------------------------------
resp_rate
## ------Cuff Leak (ml)Cuff leak (ml) ?cannot use ---------------------------------------------------------
# item 에서 cuff leak present(1095) cuff leak(140), cuff Pressure-airway  둘다  yes or no 라서 쓸 수 없음
cuffleakchartevnetslist <- list()

for (i in 1:17) {
  cuffleakchartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
    filter(itemid %in% c(1095,140))
  if (i == 1) {
    cuffleaklist <- cuffleakchartevnetslist[[i]]
  } else {
    cuffleaklist <- union(gcslist, cuffleakchartevnetslist[[i]])
  }
}

cuffleaklist

cuffleaklist <- cuffleaklist %>% 
  rename("cuffleaktime" = "charttime","cuffleak"="value") %>% 
  select("hadm_id", "cuffleaktime", "cuffleak")

cuffleaklist = cuffleaklist %>% 
  compute(dbplyr::in_schema("public","selcuffleaklist"), temporary = FALSE, overwrite = TRUE)

selcuffleaklist

#----GCS : selgcslist--------------------------------------------------------------------------------------
gcschartevnetslist <- list()

for (i in 1:17) {
  gcschartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
    filter(itemid %in% c(723, 454, 184, 223900, 223901, 22073))
  if (i == 1) {
    gcslist <- gcschartevnetslist[[i]]
  } else {
    gcslist <- union(gcslist, gcschartevnetslist[[i]])
  }
}

gcschartevnetslist
gcslist

gcslist <- gcslist %>% 
  rename("gcstime" = "charttime","gcs"="valuenum") %>% 
  select("hadm_id", "gcstime", "gcs")

#gcslist = copy_to(conn, gcslist, dbplyr::in_schema("public","gcslist"), overwrite = T, temporary = FALSE)
gcslist = gcslist %>% 
  compute(dbplyr::in_schema("public","selgcslist"), temporary = FALSE, overwrite = TRUE)

selgcslist

#-----  RSBI  --------------------------------------------------------------------------------------------

RSBIchartevnetslist <- list()

for (i in 1:17) {
  RSBIchartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
    filter(itemid %in% c(224740.644,595,1397))
  if (i == 1) {
    RSBIlist <- RSBIchartevnetslist[[i]]
  } else {
    RSBIlist <- union(RSBIlist, RSBIchartevnetslist[[i]])
  }
}

RSBIlist

RSBIlist <- RSBIlist %>% 
  rename("RSBItime" = "charttime","RSBI"="valuenum","RSBI_unit"="valueuom") %>% 
  select("hadm_id", "RSBItime", "RSBI","RSBI_unit")

selRSBIlist = RSBIlist %>% 
  compute(dbplyr::in_schema("public","selRSBIlist"), temporary = FALSE, overwrite = TRUE)

selRSBIlist

#------ Pimax(Peak insp.Pressure) -------------------------

pimaxchartevnetslist <- list()

for (i in 1:17) {
  pimaxchartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
    filter(itemid %in% c(224695))
  if (i == 1) {
    Pimaxlist <- pimaxchartevnetslist[[i]]
  } else {
    Pimaxlist <- union(Pimaxlist, pimaxchartevnetslist[[i]])
  }
}

Pimaxlist

Pimaxlist <- Pimaxlist %>% 
  rename("pimaxtime" = "charttime","pimax"="valuenum","pimax_unit"="valueuom") %>% 
  select("hadm_id", "pimaxtime", "pimax","pimax_unit")

selpimaxlist = Pimaxlist %>% 
  compute(dbplyr::in_schema("public","selpimaxlist"), temporary = FALSE, overwrite = TRUE)

selpimaxlist

#------- V(te) :Tidal volume 1 회 호흡 시 전달되는 공기의 양 (정상 성인기준 400-500 ml)  ---------------------
vtchartevnetslist <- list()

for (i in 1:17) {
  vtchartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
    filter(itemid %in% c(224685,224686, 2400))
  if (i == 1) {
    vtlist <- vtchartevnetslist[[i]]
  } else {
    vtlist <- union(vtlist, vtchartevnetslist[[i]])
  }
}

vtlist

vtlist <- vtlist %>% 
  rename("vttime" = "charttime","vt"="valuenum","vt_unit"="valueuom") %>% 
  select("hadm_id", "vttime", "vt","vt_unit")

selvtlist = vtlist %>% 
  compute(dbplyr::in_schema("public","selvtlist"), temporary = FALSE, overwrite = TRUE)

selvtlist

#-------- Ve : exhaled minute volume 분당 호기량 1분동안 전달되는 공기의 총량 L/min -----------------------------

Vechartevnetslist <- list()

for (i in 1:17) {
  Vechartevnetslist[[i]] <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", paste0("chartevents_",i))) %>%
    filter(itemid %in% c(449, 450, 448, 445, 650, 1010, 1102, 1323, 1380, 1724, 1664, 2319))
  if (i == 1) {
    Velist <- Vechartevnetslist[[i]]
  } else {
    Velist <- union(Velist, Vechartevnetslist[[i]])
  }
}

Velist

Velist <- Velist %>% 
  rename("Vetime" = "charttime","Ve"="valuenum","Ve_unit"="valueuom") %>% 
  select("hadm_id", "Vetime", "Ve","Ve_unit")

selVelist = Velist %>% 
  compute(dbplyr::in_schema("public","selVelist"), temporary = FALSE, overwrite = TRUE)

selVelist


#### 2차 셀렉션 ########################################################################################

##----Data Size 줄이기--------------------------
# gcs ( selgcslist ) RSBI(selRSBIlist), Pimax(selpimaxlist) Vt(selvtlist), Ve ( selVelist) Resp Rate (resp_rate),SpO2(spo2_before_wean) extubation 이후 삭제
# extubation Time 은 어디에??? add_extubation_time

extubationtime = add_extubation_time %>% 
  select("hadm_id","extubation_time")

extubationtime = extubationtime %>% 
  compute(dbplyr::in_schema("public","extubationtime"), temporary = FALSE, overwrite = TRUE)

extubationtime

#RR ===============================================================================================
#Resp Rate -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>time  extubation 전에 시행한 것만 필요
resp_rate
#RR1에 Extubation  Time 붙이고, Extubation 이후에 시행한 건은 모두 없앰.
RR1 <- resp_rate %>% 
  left_join(extubationtime, by = c("hadm_id")) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > rr_time )
#RR1에 컬럼명 변경해서 다시 넣기 필요한 컬럼만 뽑기
RR1 <- RR1 %>% 
  rename("RRtime" = "rr_time", "RR" = "rr", "RRunit" = "valueuom") %>%
  select("hadm_id","extubation_time", "RRtime","RR","RRunit")
#RR2에 RR~Extubation Time 까지 시간을 구하기 + 정렬까지
RR2<- RR1 %>% 
  mutate(RR_to_Extubation_hour = day(extubation_time-RRtime)*24+hour(extubation_time-RRtime))
RR2
RR2 = RR2 %>% 
  compute(dbplyr::in_schema("public","RR2"), temporary = FALSE, overwrite = TRUE)

RR2 <- dplyr::tbl(conn, dbplyr::in_schema("public", "RR2"))


RR2 %>% 
  summarize(mean(RR_to_Extubation_hour, na.rm = TRUE))
RR2 %>% 
  summarize(max(RR_to_Extubation_hour, na.rm = TRUE))
RR2 %>% 
  summarize(min(RR_to_Extubation_hour, na.rm = TRUE))

#분포를 볼 수 없나???? ggplot(data=RR2) %>% geom_density((mapping = aes(x=RR_to_Extubation_hour), ,adjust = 1/2)) ???????????????

#-----------------------------------------------------------------

RR3 = RR2 %>% 
  filter(RR_to_Extubation_hour <= 24)
RR3  = RR3 %>% 
  compute(dbplyr::in_schema("public","RR3"), temporary = FALSE, overwrite = TRUE)
#RR3에서 같은 날짜에 있는 데이터들을 평균을 할지, 아니면 가장 가까운 데이터를 쓸지 결정이 필요함 ??????????????????????
#-------------------------------------------------------------------

#### SpO2(spo2_before_wean) ==========================================================================================================
SpO2_1 <- spo2_before_wean %>% 
  left_join(extubationtime, by = c("hadm_id")) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > spo2_time )
SpO2_1
#SpO2_1에 컬럼명 변경해서 다시 넣기 필요한 컬럼만 뽑기
SpO2_1 <- SpO2_1 %>% 
  rename("spo2time" = "spo2_time", "spo2unit" = "spo2_unit") %>%
  select("hadm_id","extubation_time", "spo2time","spo2","spo2unit")
#SpO2_1에 SpO2~Extubation Time 까지 시간을 구하기 + 정렬까지
SpO2_2<- SpO2_1 %>% 
  mutate(spo2_to_Extubation_hour = day(extubation_time-spo2time)*24+hour(extubation_time-spo2time))
SpO2_2
SpO2_2 = SpO2_2 %>% 
  compute(dbplyr::in_schema("public","SpO2_2"), temporary = FALSE, overwrite = TRUE)

SpO2_3 = SpO2_2 %>% 
  filter(spo2_to_Extubation_hour <= 24)

SpO2_3  = SpO2_3 %>% 
  compute(dbplyr::in_schema("public","SpO2_3"), temporary = FALSE, overwrite = TRUE)

#====================================================================================================================================
#GCS -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>gcstime  extubation 전에 시행한 gcs만 필요 
gcs1 <- selgcslist %>% 
  left_join(extubationtime, by = c("hadm_id")) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > gcstime )

gcs1

#gcs1 컬럼명 변경해서 다시 넣기 필요한 컬럼만 뽑기
gcs1 <- gcs1 %>% 
  select("hadm_id","extubation_time", "gcstime","gcs")
#gcs1 SpO2~Extubation Time 까지 시간을 구하기 + 정렬까지
gcs2<- gcs1 %>% 
  mutate(gcs_to_Extubation_hour = day(extubation_time-gcstime)*24+hour(extubation_time-gcstime))
gcs2
gcs2 = gcs2 %>% 
  compute(dbplyr::in_schema("public","gcs2"), temporary = FALSE, overwrite = TRUE)

gcs3 = gcs2 %>% 
  filter(gcs_to_Extubation_hour <= 24)
gcs3 = gcs3 %>% 
  compute(dbplyr::in_schema("public","gcs3"), temporary = FALSE, overwrite = TRUE)

#=======================================================================================================================================
#RSBI -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>RSBItime  extubation 전에 시행한 것만 필요 
RSBI1 <- selRSBIlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > RSBItime )

RSBI1

RSBI1 <- RSBI1 %>% 
  rename("rsbitime" = "RSBItime","rsbi" = "RSBI", "rsbiunit" = "RSBI_unit") %>%
  select("hadm_id","extubation_time", "rsbitime","rsbi","rsbiunit")

RSBI2<- RSBI1 %>% 
  mutate(RSBI_to_Extubation_hour = day(extubation_time-rsbitime)*24+hour(extubation_time-rsbitime))
RSBI2
RSBI2 = RSBI2 %>% 
  compute(dbplyr::in_schema("public","RSBI2"), temporary = FALSE, overwrite = TRUE)

#RSBI3 = RSBI2 %>% 
#  filter(RSBI_to_Extubation_hour <= 72)
#RSBI3 #RSBI는 시간을 안정하고 봐야 할듯.... 시간으로 자르면 작아짐?????????????????????????????????????????????????????????????????
#==============================================================================================================================================
      
#pimax -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>time  extubation 전에 시행한 것만 필요 
pimax1 <- selpimaxlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > pimaxtime )

pimax1
pimax1 <- pimax1 %>% 
  rename("pimaxunit" = "pimax_unit") %>%
  select("hadm_id","extubation_time", "pimaxtime","pimax","pimaxunit")

pimax2<- pimax1 %>% 
  mutate(Pimax_to_Extubation_hour = day(extubation_time-pimaxtime)*24+hour(extubation_time-pimaxtime))
pimax2
pimax2 = pimax2 %>% 
  compute(dbplyr::in_schema("public","pimax2"), temporary = FALSE, overwrite = TRUE)

pimax3 = pimax2 %>% 
  filter(Pimax_to_Extubation_hour <= 24)
pimax3
pimax3 = pimax3 %>% 
  compute(dbplyr::in_schema("public","pimax3"), temporary = FALSE, overwrite = TRUE)



count(pimax2)
count(pimax3)

#===============================================================================================================================================
#Vt -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>time  extubation 전에 시행한 것만 필요 
Vt1 <- selvtlist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > vttime )

Vt1
Vt1 <- Vt1 %>% 
  rename("vtunit" = "vt_unit") %>%
  select("hadm_id","extubation_time", "vttime","vt","vtunit")

Vt2<- Vt1 %>% 
  mutate(Vt_to_Extubation_hour = day(extubation_time-vttime)*24+hour(extubation_time-vttime))
Vt2
Vt2 = Vt2 %>% 
  compute(dbplyr::in_schema("public","Vt2"), temporary = FALSE, overwrite = TRUE)

Vt3 = Vt2 %>% 
  filter(Vt_to_Extubation_hour <= 24)
Vt3
Vt3 = Vt3 %>% 
  compute(dbplyr::in_schema("public","Vt3"), temporary = FALSE, overwrite = TRUE)

#=============================================================================================================================================
#Ve -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제, extubation_time>time  extubation 전에 시행한 것만 필요 
Ve1 <- selVelist %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > Vetime )

Ve1
Ve1 <- Ve1 %>% 
  rename("vetime"="Vetime","ve"="Ve","veunit" = "Ve_unit") %>%
  select("hadm_id","extubation_time", "vetime","ve","veunit")

Ve2<- Ve1 %>% 
  mutate(Ve_to_Extubation_hour = day(extubation_time-vetime)*24+hour(extubation_time-vetime))
Ve2
Ve2 = Ve2 %>% 
  compute(dbplyr::in_schema("public","Ve2"), temporary = FALSE, overwrite = TRUE)

Ve3 = Ve2 %>% 
  filter(Ve_to_Extubation_hour <= 24)
Ve3
Ve3 = Ve3 %>% 
  compute(dbplyr::in_schema("public","Ve3"), temporary = FALSE, overwrite = TRUE)

## 값처리 ######################################################################################
RR3  #mean respiratory rate
SpO2_3  #Last Spo2
gcs3  # 중복값 있을 시 Last gcs 로 선택
RSBI2  #가장 최근 값(Last)
pimax3  #mean pimax
Vt3  #mean vt3
Ve3  #mean ve3

#by(RR3,RR_to_Extubation_hour, summary)
#Hmisc::describe(RR3$RR_to_Extubation_hour)
#stat.desc(RR3)
#psych::describeBy(RR3, RR3$RR_to_Extubation_hour)

skim(RR3) #데이터 통계량 보기
#RR3의 아웃라이어 2016 이 있어 60 이상값은 제거함
#RR3의 호흡수 0 제거 -> 기계에서 탈착 혹은 사망

RR3_1 = RR3 %>% 
  filter(RR > 0 & RR <60) #RR = 0 은 측정 불가 혹은 미인식 자료로 인지 통상 호흡정상범위는 20임

RR3_1
skim(RR3_1)

RR3_1 = RR3_1 %>% 
  compute(dbplyr::in_schema("public","RR3_1"), temporary = FALSE, overwrite = TRUE)

RR3_1 # Mean 값 출력하기

# RR3_2<- RR3_1 %>% 
#   group_by(hadm_id, extubatqion_time) %>% 
#   mutate(mean_RR24 = tapply(RR, mean, group_by = c(hadm_id, extubation_time)))

RR24 <- RR3_1 %>% 
  group_by(hadm_id, extubation_time) %>% 
  summarize(mean_RR24 = mean(RR, na.rm = TRUE)) 

RR12<- RR3_1 %>% 
  filter(RR_to_Extubation_hour <= 12) %>% 
  group_by(hadm_id, extubation_time) %>% 
  summarize(mean_RR12 = mean(RR))

RR_f1<- RR24 %>% 
  left_join(RR12, by = c("hadm_id", "extubation_time"))

RR_f1 =  RR_f1 %>% 
  compute(dbplyr::in_schema("public","RR_f1"), temporary = FALSE, overwrite = TRUE)

#=======================================================================================

SpO2_3
skim(SpO2_3) #unique 936

SpO2_3_1 = SpO2_3 %>% 
  filter(spo2 > 70 & spo2_to_Extubation_hour <= 24)

SpO2_f1<- SpO2_3_1 %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(spo2time), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1)

SpO2_f1 =  SpO2_f1 %>% 
  compute(dbplyr::in_schema("public","SpO2_f1"), temporary = FALSE, overwrite = TRUE)

?rank
?group_by
?arrange
?top_n

skim(SpO2_f1)
#===================================================
skim(gcs3)

gcs3_1 = gcs3 %>% 
  filter(gcs_to_Extubation_hour <= 24)

gcs3_1

GCS_f1 <-gcs3_1 %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(gcstime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1)

GCS_f1 =  GCS_f1 %>% 
  compute(dbplyr::in_schema("public","GCS_f1"), temporary = FALSE, overwrite = TRUE)

skim(GCS_f1)


#====================================================

skim(RSBI2) #unique 건이 11건 뿐... 아예 빼는 것도 방법
#(Rapid shallow breathing index)

RSBI2_1 = RSBI2
RSBI2_1 <- RSBI2 %>% 
  filter(!is.na(rsbi))

RSBI2_1

RSBI_f1 <- RSBI2_1 %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(rsbitime), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1)

RSBI_f1 =  RSBI_f1 %>% 
  compute(dbplyr::in_schema("public","RSBI_f1"), temporary = FALSE, overwrite = TRUE)

skim(RSBI_f1)


#===================================================
skim(pimax3) #maximal inspiratory pressure https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2739366/
pimax3_1 = pimax3 %>% 
  filter(Pimax_to_Extubation_hour <= 24 & pimax > 0) %>% 
  filter(!is.na(pimax))

pimax3_1

# skim(pimax3_1) #scatter 로 볼 필요 있음
# pimax3_1 = pimax3_1 %>% 
#   compute(dbplyr::in_schema("public","pimax3_1"), temporary = FALSE, overwrite = TRUE)

Pimax24 <- pimax3_1 %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_pimax24 = mean(pimax, na.rm = TRUE)) %>% 
  select(hadm_id, extubation_time, mean_pimax24, pimaxunit) %>% 
  distinct()


Pimax12 <- pimax3_1 %>% 
  filter(Pimax_to_Extubation_hour <= 12) %>% 
  group_by(hadm_id, extubation_time) %>% 
  summarize(mean_pimax12 = mean(pimax))

Pimax_f1 <- Pimax24 %>% 
  left_join(Pimax12, by = c("hadm_id", "extubation_time")) %>% 
  select(hadm_id, extubation_time, mean_pimax24, mean_pimax12, pimaxunit)

Pimax_f1 =  Pimax_f1 %>% 
  compute(dbplyr::in_schema("public","Pimax_f1"), temporary = FALSE, overwrite = TRUE)


#===================================================
Vt3
skim(Vt3)
Vt3_1 = Vt3 %>% 
  filter(Vt_to_Extubation_hour <= 24) %>% 
  filter(vt > 0) %>% 
  filter(!is.na(vt))
  
Vt3_1


Vt24 <- Vt3_1 %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_vt24 = mean(vt, na.rm = TRUE)) %>% 
  select(hadm_id, extubation_time, mean_vt24, vtunit) %>% 
  distinct()


Vt12 <- Vt3_1 %>% 
  filter(Vt_to_Extubation_hour <= 12) %>% 
  group_by(hadm_id, extubation_time) %>% 
  summarize(mean_vt12 = mean(vt))


Vt_f1 <- Vt24 %>% 
  left_join(Vt12, by = c("hadm_id", "extubation_time")) %>% 
  select(hadm_id, extubation_time, mean_vt24, mean_vt12, vtunit)

Vt_f1 =  Vt_f1 %>% 
  compute(dbplyr::in_schema("public","Vt_f1"), temporary = FALSE, overwrite = TRUE)


# skim(Vt3_1)
# Vt3_1 = Vt3_1 %>% 
#   compute(dbplyr::in_schema("public","Vt3_1"), temporary = FALSE, overwrite = TRUE)

##----------------------------------------------------------------
Vt3_1 <- dplyr::tbl(conn, dbplyr::in_schema("public", "Vt3_1"))

Vt3_2 <- collect(Vt3_1)
hist(Vt3_2$vt) #6000 근방에 작은 데이터 군집이 있음
#chrome-extension://efaidnbmnnnibpcajpcglclefindmkaj/viewer.html?pdfurl=https%3A%2F%2Fwww.zoll.com%2F-%2Fmedia%2Fpublic-site%2Fproducts%2Fventilators%2F906-0731-01-05-sf_b.ashx&clen=5876109&chunk=true
#0, 과 6000은 disconnect 또는 다른 세팅값으로 보이므로 제거
#hyper vt는 10ml/kg 이상이다.

TA = Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt != 6000) %>% 
  filter(vt >= 3000) 

TA #Vt 가 3000이 넘는 데이터는 전체 데이터 중 30개이다.

A = Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 6000) %>% 
  filter(vt != 1) %>% 
  filter(hadm_id %in% TA$hadm_id)

view(A)

#A를 본 결과 같은 시간(분단위)에 측정한 결과인데 값이 상이하여, 오타로 보고 해당 데이터 삭제하였다.
#같은 시간에 비교데이터는 통상 정상범위내 300-500 ml 의 값과 유사하였음.
#Tidal volume 은 기계가 한번 숨을 불어넣어주는 공기의 양 : 
#심한 폐쇄성/제한성 폐질환 환자에서 기도 압력이 증가해 있어 일회 환기량(Tidal volume, Tv) 이 제한됭 수 있음.
#보통 kg 당 7ml // 환자의 키에 의존 (몸무게가 아님), Vt가 감소할때 사강의 비율이 증가하므로 Vt가 감소하면 호흡수를 증가시킨다.
#IFR 최대 흡기 속도(Inspiratory flow rate, IFR Vt* RR = 정상성인은 60l)
# https://m.blog.naver.com/PostView.naver?isHttpsRedirect=true&blogId=congguksu&logNo=70178786032
#(10ml/kg)
#=흡기 기도 압력은 종종 높으며, 이는 폭기된 폐의 과도한 팽창 또는 "신장"의 존재를 시사합니다. 동물에서 큰 일회 호흡량을 사용한 환기는 폐 상피와 내피의 파괴, 폐 염증, 무기폐, 저산소증 및 염증 매개체의 방출을 유발했습니다
#https://www.nejm.org/doi/full/10.1056/nejm200005043421801
#급성 폐 손상 및 급성 호흡 곤란 증후군이 있는 환자의 환기 중 일회 호흡량을 낮추면 폐 손상과 염증 매개체의 방출이 감소할 수 있습니다. 16-18 그러나 이 접근법은 호흡성 산증을 유발 하고 16,17 동맥 산소화를 감소시킬 수 있습니다 19,20따라서 이러한 환자를 돌보는 데 있어 일부 목표의 우선순위를 변경해야 할 수 있습니다. 전통적인 접근 방식에서는 과도한 스트레치로부터 폐를 보호하는 것보다 동맥 이산화탄소의 정상 부분압과 pH에 도달하는 것이 더 우선시됩니다. 더 낮은 일회 호흡량을 포함하는 접근 방식에서는 그 반대가 사실입니다. 통제되지 않은 연구에서는 더 낮은 일회 호흡량을 사용하면 급성 폐 손상 및 급성 호흡 곤란 증후군 환자의 사망률을 줄일 수 있다고 제안 했지만 17 폐 보호 환기 전략에 대한 4건의 무작위 시험 결과는 상충되었습니다. 21-24 본 시험은 기계적 환기와 함께 더 낮은 일회 호흡량을 사용하는 것이 그러한 환자에서 중요한 임상 결과를 개선할 수 있는지 여부를 결정하기 위해 수행되었습니다.


# Vt3_2 %>% 
#   filter(vt > 5000)
# 
# Vt3_2 %>% 
#   filter(vt != 0) %>% 
#   filter(vt != 6000) %>% 
#   filter(vt != 1) %>% 
#   filter(hadm_id == 102667)
# 
# Vt3_2 %>% 
#   filter(vt != 0) %>% 
#   filter(vt != 6000) %>% 
#   filter(vt != 1) %>% 
#   filter(hadm_id == 142899) %>% 
#   slice(20:40)
# 
# Vt3_2 %>% 
#   filter(vt != 0) %>% 
#   filter(vt != 6000) %>% 
#   filter(vt != 1) %>% 
#   filter(hadm_id == 195925) %>% 
#   slice(1:20)
# 
# Vt3_2 %>% 
#   filter(hadm_id == 170587) %>% 
#   filter(vttime > as_datetime("2162-10-15 22:50:00"))
# 
# Vt3_2 %>% 
#   filter(hadm_id == 170587) %>% 
#   with(hist(vt))

Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt < 3000 & vt >=1000) # vt가 1000이상 3000미만은 471개 였다.

TA2 = Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt < 6000) %>% 
  filter(vt < 3000 & vt >=2000) # vt가 2000이상 3000미만은 43개 였다.

B = Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt < 6000) %>% 
  filter(hadm_id %in% TA2$hadm_id)

TA2
view(B)
#같은시간에 12와 2060대 함께 있음 
#50-2000의 값만 남기고 전부 없애버리기

Vt3_2 %>%
  filter(vt >= 50) %>% 
  filter(vt <= 2000) %>% 
  with(hist(vt))

# Tidal volume initial set 값 (기계상)
#그다음 봐야 할 것 = 같은 날짜 같은 시간에 다른데이터



Vt3_3 = Vt3_2 %>%
  filter(vt >= 50) %>% 
  filter(vt <= 2000)

Vt3_3

Vt3_3 %>% 
  group_by(hadm_id, extubation_time, vttime)
  distinct()
  

  mutate(mean_pimax24 = mean(pimax, na.rm = TRUE)) %>% 
  select(hadm_id, extubation_time, mean_pimax24, pimaxunit) %>% 
  distinct()




#====================================================
skim(Ve3)
Ve3  

Ve3_1 = Ve3 %>% 
  filter(Ve_to_Extubation_hour <= 24)

skim(Ve3_1)
Ve3_1 = Ve3_1 %>% 
  compute(dbplyr::in_schema("public","Ve3_1"), temporary = FALSE, overwrite = TRUE)
  


#-----SQL---------------------------------------------------------------------------

#ois = copy_to(conn, oasis, dbplyr::in_schema("public","oasis"), overwrite = T, temporary = FALSE)
#ois
#sis = copy_to(conn, sapsii, dbplyr::in_schema("public","sapsii"), overwrite = T, temporary = FALSE)
#sis

# 
# 
# resp_rate
# spo2_before_wean
# 
# seloasis = oasis %>% 
#   select(hadm_id, oasis)
# selsapsii = sapsii %>% 
#   select(hadm_id, sapsii)
# selspo2 = spo2_before_wean %>% 
#   select(hadm_id, spo2_time, spo2, spo2_unit)
# selgcs = gcsext %>% 
#   select(hadm_id,gcstime, gcs )
# 
# 
# 
# 
# selgcs
# gcsext <- rename(gcsext, "gcstime"="charttime" ,  "gcs" = "valuenum")
# gcsext
# 
# admissions %>%
#   left_join(patients, by = "subject_id") %>% 
#   left_join(procedures_icd, by = c("hadm_id", "subject_id")) %>%
#   select(
#     subject_id,
#     hadm_id,
#     seq_num,
#     admittime,
#     dischtime,
#     deathtime,
#     religion,
#     ethnicity,
#     diagnosis,
#     hospital_expire_flag,
#     icd9_code,
#     gender,
#     dob,
#     dod
#   ) %>% 
#   mutate(age = trunc(as.numeric(as.Date(admittime)-as.Date(dob))/365.242)) %>% 
#   left_join(seloasis, by = c("hadm_id")) %>%  #oasis 컬럼만 붙이면 됨
#   left_join(selsapsii, by = c("hadm_id")) %>%      #sapsii 만 붙이면 됨
#   left_join(selspo2, by = c("hadm_id")) %>% 
#   left_join(resp_rate,by = c("hadm_id")) %>% 
#   left_join(selgcslist, by = c("hadm_id"))
# 
# sapsii
# 
# 
# 
# gcsext
# 
# admissions %>% 
#   compute(dbplyr::in_schema("public","admissiontest"), temporary = FALSE)
# 
# 
# 
# 
# dbGetQuery(conn,
#            "SELECT table_name, table_schema FROM information_schema.tables 
#              where not table_schema = 'information_schema' and not table_schema = 'pg_catalog'") %>%
#   arrange(table_schema, table_name) %>% 
#   as_tibble() %>%
#   glimpse()
# 
# 
# dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions")) %>% 
#   select("dischtime") %>% 
#   filter(dischtime >"2177-03-12") %>% 
#   count()
# 
# 
# dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions")) %>% 
#   select("dischtime") %>% 
#   filter(dischtime >"2177-03-12") %>% 
#   collect() -> sub1 #DB???????? R 媛앹껜濡? ?꽆湲곌린
# 
# sub1
# 
# 
# write_csv(sub1,"sub1.csv")
# # write_csv(x, path, append = FALSE, col_names = !append)
# #https://dbplyr.tidyverse.org/reference/join.tbl_sql.html
# 
# left_join(admissions, icustays, by = "subject_id")
# 
# icustays %>% 
#   mutate(wardchange = if_else(first_careunit != last_careunit, 1, 0)) %>% #???щ읆 留뚮???????????
#   select(first_careunit, last_careunit, wardchange)
# 
# icustays
# icustays %>%  
#   distinct(first_careunit) #????????????? ????????????...
# 
# icustays %>% 
#   count(first_careunit) #????????????????????????????
# 
# icustays
# group_by(first_careunit) %>% 
#   summarise() # ???????? 移댄???怨좊??????????????? ???????????? 媛?????? ???????????????? ????????????
# 
# #-------------------------------------------------------------------------
# 
# icustays %>% filter(first_careunit %LIKE% "%CC%") #like??? 찾기
