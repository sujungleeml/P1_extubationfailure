install.packages("RPostgres")
install.packages("DBI")
install.packages("dbplyr")
install.packages('tidyverse')

library(dplyr)
library(DBI)
library(readr)
library(dbplyr)
library(stringr)
library(readr)
library(tidyverse)
library(vroom)
library(lubridate)
#-------connect--------------------------------------------------------------

host = "localhost"
port = "5432"
DB = "mimic3"
UserName = "postgres" 

conn <- DBI::dbConnect(
  RPostgres::Postgres(),
  dbname = DB,
  user = UserName,
  password = "Pass2020!",
  host = host,
  port = port,
  bigint = "numeric"
)
#---------tables------------------------------------------------------------
admission = read_csv("c:/Data_for/ADMISSIONS.csv")
patients = read_csv("c:/Data_for/PATIENTS.csv") 
procedures_icd = read_csv("c:/Data_for/PROCEDURES_ICD.csv")
procedureevents_mv = read_csv("c:/Data_for/PROCEDUREEVENTS_MV.csv")
spo2_before_wean = read_csv("c:/Data_for/table/spo2_before_wean")
#oasis = read_csv("C:/Data_for/table/oasis")
#sapsii = read_csv("C:/Data_for/table/sapsii")

admissions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions"))
callout <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "callout"))
caregivers <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "caregivers"))
chartevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents"))
chartevents_1 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_1"))
chartevents_2 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_2"))
chartevents_3 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_3"))
chartevents_4 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_4"))
chartevents_5 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_5"))
chartevents_6 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_6"))
chartevents_7 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_7"))
chartevents_8 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_8"))
chartevents_9 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_9"))
chartevents_10 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_10"))
chartevents_11 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_11"))
chartevents_12 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_12"))
chartevents_13 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_13"))
chartevents_14 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_14"))
chartevents_15 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_15"))
chartevents_16 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_16"))
chartevents_17 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_17"))
cptevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "cptevents"))
d_cpt <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_cpt"))
d_icd_diagnoses <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_diagnoses"))
d_icd_precedures <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_icd_procedures"))
d_items <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_items"))
d_labitems <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_labitems"))
datetimeevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "datetimeevents"))
diagnoses_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "diagnoses_icd"))
drgcodes <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "drgcodes"))
icustays <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "icustays"))
inputevents_cv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "inputevents_cv"))
inputevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "inputevents_mv"))
labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))
microbiologyevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "microbiologyevents"))
noteevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "noteevents"))
outputevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "outputevents"))
patients <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "patients"))
prescriptions <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "prescriptions"))
procedureevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedureevents_mv"))
procedures_icd <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedures_icd"))
services <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "services"))
transfers <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "transfers"))


#-----SQL---------------------------------------------------------------------------

ois = copy_to(conn, oasis, dbplyr::in_schema("public","oasis"), overwrite = T, temporary = FALSE)
ois
sis = copy_to(conn, sapsii, dbplyr::in_schema("public","sapsii"), overwrite = T, temporary = FALSE)
sis

oasis <- dplyr::tbl(conn, dbplyr::in_schema("public","oasis"))
sapsii <- dplyr::tbl(conn, dbplyr::in_schema("public","sapsii"))
spo2_before_wean <- dplyr::tbl(conn, dbplyr::in_schema("public","spo2_before_wean"))
resp_rate <- dplyr::tbl(conn, dbplyr::in_schema("public", "resp_rate"))

resp_rate
spo2_before_wean

seloasis = oasis %>% 
  select(hadm_id, oasis)
selsapsii = sapsii %>% 
  select(hadm_id, sapsii)
selspo2 = spo2_before_wean %>% 
  select(hadm_id, spo2_time, spo2, spo2_unit)
selgcs = gcsext %>% 
  select(hadm_id,gcstime, gcs )

selgcs
gcsext <- rename(gcsext, "gcstime"="charttime" ,  "gcs" = "valuenum")
gcsext

admissions %>%
  left_join(patients, by = "subject_id") %>% 
  left_join(procedures_icd, by = c("hadm_id", "subject_id")) %>%
  select(
    subject_id,
    hadm_id,
    seq_num,
    admittime,
    dischtime,
    deathtime,
    religion,
    ethnicity,
    diagnosis,
    hospital_expire_flag,
    icd9_code,
    gender,
    dob,
    dod
  ) %>% 
  mutate(age = trunc(as.numeric(as.Date(admittime)-as.Date(dob))/365.242)) %>% 
  left_join(seloasis, by = c("hadm_id")) %>%  #oasis 컬럼만 붙이면 됨
  left_join(selsapsii, by = c("hadm_id")) %>%      #sapsii 만 붙이면 됨
  left_join(selspo2, by = c("hadm_id")) %>% 
  left_join(resp_rate,by = c("hadm_id")) %>% 
  left_join(selgcs, by = c("hadm_id"))

sapsii

for (i in 1:17) {
  chartevents_i %>% 
    filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
}
#노가다 
gcsch1<- chartevents_1 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch2<- chartevents_2 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch3<- chartevents_3 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch4<- chartevents_4 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch5<- chartevents_5 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch6<- chartevents_6 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch7<- chartevents_7 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch8<- chartevents_8 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch9<- chartevents_9 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch10<- chartevents_10 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch11<- chartevents_11 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch12<- chartevents_12 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch13<- chartevents_13 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch14<- chartevents_14 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch15<- chartevents_15 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch16<- chartevents_16 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))
gcsch17<- chartevents_17 %>% 
  filter(itemid %in% c(723, 454, 184, 223900, 223901, 220739))


gcsext<- union(gcsch1, gcsch2, gcsch3, gcsch4, gcsch5, gcsch6, gcsch7, 
               gcsch8, gcsch9, gcsch10, gcsch11, gcsch12, gcsch13, gcsch14, gcsch15, gcsch16, gcsch17)
gcsext = copy_to(conn, gcsext, dbplyr::in_schema("public","gcsext"), overwrite = T, temporary = FALSE)
gcsext

admissions %>% 
  compute(dbplyr::in_schema("public","admissiontest"), temporary = FALSE)

















dbGetQuery(conn,
           "SELECT table_name, table_schema FROM information_schema.tables 
             where not table_schema = 'information_schema' and not table_schema = 'pg_catalog'") %>%
  arrange(table_schema, table_name) %>% 
  as_tibble() %>%
  glimpse()


dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions")) %>% 
  select("dischtime") %>% 
  filter(dischtime >"2177-03-12") %>% 
  count()


dplyr::tbl(conn, dbplyr::in_schema("mimic3", "admissions")) %>% 
  select("dischtime") %>% 
  filter(dischtime >"2177-03-12") %>% 
  collect() -> sub1 #DB???????? R 媛앹껜濡? ?꽆湲곌린

sub1


write_csv(sub1,"sub1.csv")
# write_csv(x, path, append = FALSE, col_names = !append)
#https://dbplyr.tidyverse.org/reference/join.tbl_sql.html

left_join(admissions, icustays, by = "subject_id")

icustays %>% 
  mutate(wardchange = if_else(first_careunit != last_careunit, 1, 0)) %>% #???щ읆 留뚮???????????
  select(first_careunit, last_careunit, wardchange)

icustays
icustays %>%  
  distinct(first_careunit) #????????????? ????????????...

icustays %>% 
  count(first_careunit) #????????????????????????????

icustays
group_by(first_careunit) %>% 
  summarise() # ???????? 移댄???怨좊??????????????? ???????????? 媛?????? ???????????????? ????????????

#-------------------------------------------------------------------------

icustays %>% filter(first_careunit %LIKE% "%CC%") #like??? 찾기
