install.packages("tidymodels")
library(readr)
library(dplyr)
library(ggplot2)
rr_til_90min = read_csv("C:/Users/sujung lee/Documents/20211115_mimicpublic_csv/rr_til_90min")
rr_til_90min %>% 
  head(20)
rr_til_90min %>% 
  select(ends_with("time")) 

## 1. rr_ext_diff_time : Extubation_time 1분전, Extubation time 30분전, Extubation time 60분저, Extuabtion Time 90분전

rr_c = rr_til_90min %>% 
  group_by(hadm_id) %>% 
  mutate(rr_c = if_else(rr_ext_diff_time >= 0 & rr_ext_diff_time <= 15, "1m", 
                        if_else(rr_ext_diff_time >15 & rr_ext_diff_time <= 45, "30m",
                                if_else(rr_ext_diff_time > 45 & rr_ext_diff_time <= 75, "60m",
                                        if_else(rr_ext_diff_time > 75 & rr_ext_diff_time <= 90, "90m", "")))))


rr_c = rr_til_90min %>% 
  group_by(hadm_id) %>% 
  mutate(rr_c = if_else(rr_ext_diff_time >= 0 & rr_ext_diff_time <= 20, "0-20",
                        if_else(rr_ext_diff_time >20 & rr_ext_diff_time <= 40, "21-40m",
                                if_else(rr_ext_diff_time > 40 & rr_ext_diff_time <= 60, "41-60m", "")))) 


rr_til_90min %>% 
  group_by(hadm_id) %>% 
  summarise(n = mean(rr_ext_diff_time)) %>% 
  with(hist(n))

rr_til_90min %>% 
  with(hist(rr_ext_diff_time))

#3개 다 있는건 439 개 

rr_c %>% 
  select(hadm_id, rr_c) %>% 
  distinct() %>% 
  count() %>% 
  ungroup() %>% 
  summarise(mean(n))


tid = rr_c %>% 
  select(hadm_id, rr_c) %>% 
  distinct() %>% 
  filter(rr_c != "") %>% 
  count() %>% 
  filter(n == 2) %>% 
  ungroup()

tid %>% 
  left_join(rr_c, by = "hadm_id") %>% 
  select(hadm_id, rr_c) %>%
  filter(rr_c != "") %>% 
  distinct() %>% 
  count(rr_c)

# ref 구간 평균으로 계산할지 ? /  첫번째 값으로 할지?

rr_til_90min %>%
  filter(hadm_id == 1)

%>% 
  group_by(hadm_id) %>% 
  summarise(m_rr = mean(rr)) %>% 
  filter(m_rr <= 5)
# 4000명중 4명이 구간단위로 했을때 147
# 분산을 넣는다? rr의 평균과 rr의 분산으로
# 결측치가 데이터다.. -> rr의 정상치는 20


## 110348, 111504, 150117 은 m_rr이 0 이므로, 제거한다.