 # #################################
  # Purpose: Create a view of the urine output for each ICUSTAY_ID over the first 24 hours.
# #################################
 
#https://github.com/MIT-LCP/mimic-code/tree/main/mimic-iii/concepts/firstday
  
 library(tidyverse)
 library(vroom)
 library(lubridate)
 
 icustays <- vroom("G:/내 드라이브/Data/MIMIC3/icustays.csv")
 outputevents <- vroom("G:/내 드라이브/Data/MIMIC3/outputevents.csv")
 
 
icustays
#d_items %>% 
#  filter(ITEMID == 227488)

A<- left_join(icustays, outputevents, by =c('SUBJECT_ID', 'HADM_ID', 'ICUSTAY_ID'))

titemid <- c(
  # these are the most frequently occurring urine output observations in CareVue
  40055, # "Urine Out Foley"
  43175, # "Urine ."
  40069, # "Urine Out Void"
  40094, # "Urine Out Condom Cath"
  40715, # "Urine Out Suprapubic"
  40473, # "Urine Out IleoConduit"
  40085, # "Urine Out Incontinent"
  40057, # "Urine Out Rt Nephrostomy"
  40056, # "Urine Out Lt Nephrostomy"
  40405, # "Urine Out Other"
  40428, # "Urine Out Straight Cath"
  40086,#	Urine Out Incontinent
  40096, # "Urine Out Ureteral Stent #1"
  40651, # "Urine Out Ureteral Stent #2"
  
  # these are the most frequently occurring urine output observations in MetaVision
  226559, # "Foley"
  226560, # "Void"
  226561, # "Condom Cath"
  226584, # "Ileoconduit"
  226563, # "Suprapubic"
  226564, # "R Nephrostomy"
  226565, # "L Nephrostomy"
  226567, #	Straight Cath
  226557, # R Ureteral Stent
  226558, # L Ureteral Stent
  227488, # GU Irrigant Volume In
  227489  # GU Irrigant/Urine Volume Out
)

# NA is 0

A %>% 
  filter(ITEMID %in% titemid) %>% 
  #distinct(ITEMID) 
  filter(CHARTTIME >= INTIME,  CHARTTIME <= INTIME + days(1)) %>%
#  select(CHARTTIME, INTIME)
           select(SUBJECT_ID, HADM_ID, ICUSTAY_ID, ITEMID, VALUE) %>% #ctl shift M 
  mutate(VALUE= if_else(is.na(VALUE),0, VALUE)) %>% 
 group_by(SUBJECT_ID, HADM_ID, ICUSTAY_ID) %>% 
   mutate(urineoutput= sum(if_else(ITEMID == 227488 & VALUE>0, -1*VALUE, VALUE))) -> Urinout


write_csv(Urinout, "Urinout.csv")