
patients
admissions
labevents

#metavision 으로 데이터를 얻은 환자들 중 중복 hadm_id 가 있는 환자 추출
icustays %>% 
  filter(dbsource != "carevue") %>% 
  filter(first_careunit != last_careunit) %>% #1446 case, 1386 subject, 1432 hadm_id
  group_by(hadm_id) %>% 
  count(hadm_id) %>% 
  filter(n>=2) %>% 
  count() #14 명


#그중 114950 환자 선택
icustays %>% 
  filter(hadm_id == 114950) %>% 
  select("subject_id","hadm_id","first_careunit","last_careunit","first_wardid","last_wardid","intime","outtime","los")

patients %>% 
  filter(subject_id == 76327)

admissions %>% 
  filter(hadm_id == 114950) %>% 
  select("hadm_id","admittime","dischtime","deathtime","admission_type","marital_status","diagnosis")



inputevents_cv %>% 
  filter(hadm_id == 114950) %>% 
  group_by(itemid) %>% 
  count(itemid)

inputevents_mv %>% 
  filter(hadm_id == 114950) %>% 
  group_by(itemid) %>% 
  count(itemid) %>% 
  arrange(desc(n)) #225799, 226452, 225158, 220959, 225797, 226453, 225823, 225166, 225851, 225910



subid = d_items %>% 
  filter(itemid %in% c(225799,226452,225158,220959,225797,226453,225823,225166, 225851, 225910, 220949, 225943,220970,225798
                       ,225159,220862,225828,225859,225884,226361,222168,223258)) %>% 
  select("itemid","label","linksto","category","unitname","param_type")

inputevents_mv %>% 
  filter(hadm_id == 114950) %>% 
  group_by(itemid) %>% 
  count(itemid) %>% 
  filter(n<3) %>% 
  left_join(subid, "itemid") %>% 
  arrange(desc(n))

diagnoses_icd %>% 
  filter(hadm_id == 114950) %>% 
  left_join(subdia, "icd9_code")

subdia = d_icd_diagnoses %>%
  filter(icd9_code %in% c("5722","51881","78959","2639","4561","2760","5070","4168","32723","2449")) %>% 
  select("icd9_code","short_title","long_title")

labevents %>% 
  filter(hadm_id == 114950) %>% 
  filter(flag == "abnormal") %>% 
  group_by(itemid) %>% 
  count(itemid) %>%
  left_join(sublab, "itemid") %>% 
  arrange(desc(n))

sublab = d_labitems %>%
  filter(itemid %in% c("50971","50983","50960","50882","50912","51006","50902","50868","50931","50893"
                       ,"50970","51221","51250","51248","51277","51222","51249","51279","51265","50885","50878")) %>% 
  select("itemid","label","fluid","category")

#chloride (50902), hematocrit (51221), glucose (50931), bilirubin (50885), AST(50878)
chlo = labevents %>% 
  filter(hadm_id == 114950) %>% 
  filter(itemid == "50902") %>% 
  arrange(charttime)

skim(chlo)
ggplot(data = chlo, aes(x = charttime, y = valuenum))+geom_line(color = "#FC4E07")

hematocrit = labevents %>% 
  filter(hadm_id == 114950) %>% 
  filter(itemid == "51221") %>% 
  arrange(charttime)
  
skim(hematocrit)
ggplot(data = hematocrit, aes(x = charttime, y = valuenum))+geom_line(color = "red")


glucose = labevents %>% 
  filter(hadm_id == 114950) %>% 
  filter(itemid == "50931") %>% 
  arrange(charttime)

skim(glucose)
ggplot(data = glucose, aes(x = charttime, y = valuenum))+geom_line(color = "#FF9933")

bilirubin = labevents %>% 
  filter(hadm_id == 114950) %>% 
  filter(itemid == "50885") %>% 
  arrange(charttime)

skim(bilirubin)
ggplot(data = bilirubin, aes(x = charttime, y = valuenum))+geom_line(color = "#994C00")

AST = labevents %>% 
  filter(hadm_id == 114950) %>% 
  filter(itemid == "50878") %>% 
  arrange(charttime)

skim(AST)
ggplot(data = AST, aes(x = charttime, y = valuenum))+geom_line(color = "#00994C")

subnote = noteevents %>% 
  filter(hadm_id == 114950) %>% 
  select("hadm_id","chartdate","category","text") %>% 
  filter(category == "Discharge summary")

view(subnote)
