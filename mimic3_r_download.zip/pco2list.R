d_labitems <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "d_labitems"))
labevents <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "labevents"))

d_labitems %>% 
  filter(fluid == "Blood") %>% 
  filter(category == "Blood Gas") %>% 
  view()


#50801 Alveolar-arterial gradient
#50804 Calculated Total CO2
#50809 Glucose
#50810 Hematocrit,calculated
#50811 Hemoglobin
#50826 Tidal Volume
#50818 pCO2
#50827 Ventilation Rate

extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
pco2list <-  dplyr::tbl(conn, dbplyr::in_schema("public", "pco2list"))


itemids = c("50818")

pco2list <- labevents %>% 
  filter(itemid == 50818)

pco2list

pco21 <- pco2list %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > charttime ) %>% 
  mutate(pco2_to_Extubation_hour = day(extubation_time-charttime)*24+hour(extubation_time-charttime)) %>% 
  rename("pco2unit"="valueuom","pco2" = "value") %>% 
  select("hadm_id","extubation_time","pco2","pco2unit","flag","pco2_to_Extubation_hour") 


pco22<- pco21 %>%
    filter(pco2_to_Extubation_hour <= 24 & pco2_to_Extubation_hour>=0) %>%
    group_by(hadm_id,extubation_time) %>% 
    mutate(pco24 = mean(pco2)) %>% 
    ungroup()
  
pco23<-pco21 %>% 
    filter(pco2_to_Extubation_hour <= 12& pco2_to_Extubation_hour>=0) %>% 
    group_by(hadm_id,extubation_time) %>% 
    mutate(pco12 = mean(pco2)) %>% 
    ungroup()
  
pco22

###부산학회용 ###
## PCO2 에 extubationtime 조인

pco2_check <- pco2list %>% 
  left_join(extubationtime, by = c("hadm_id"), "copy" = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > charttime) %>% 
  mutate(pco2_to_Extubation_hour = day(extubation_time-charttime)*24+hour(extubation_time-charttime)) %>% 
  rename("pco2unit"="valueuom","pco2"="valuenum") %>% 
  select("hadm_id","extubation_time","pco2","pco2unit","flag","pco2_to_Extubation_hour")

pco2_check %>% 
  count()
#61820

pco2_whole <- pco2_check

pco2_24 <- pco2_check %>% 
  filter(pco2_to_Extubation_hour <= 24)


anti_pco2_24<- pco2_whole %>% 
  anti_join(pco2_24, by = c("hadm_id","extubation_time"))

anti_pco2_24


#7day= 168, 8 = 192 이전 n일 결과로 24시간내 추정?

pco2_7days<- anti_pco2_24 %>% 
  filter(pco2_to_Extubation_hour <= 192) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_7days = mean(pco2)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_7days") %>% 
  distinct()
#376

pco2_5days<- anti_pco2_24 %>% 
  filter(pco2_to_Extubation_hour <= 144) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_5days = mean(pco2)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_5days") %>% 
  distinct()
#363

pco2_3days<- anti_pco2_24 %>% 
  filter(pco2_to_Extubation_hour <= 96) %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_3days = mean(pco2)) %>% 
  ungroup() %>% 
  select("hadm_id","extubation_time","mean_3days") %>%
  rename("pco2"="mean_3days")
  distinct()
#325

pco2_7days
pco2_5days
pco2_3days ##이거쓰는게...

pco2_mean_compare <- pco2_7days %>% 
  left_join(pco2_5days, by=c("hadm_id","extubation_time")) %>%  
  left_join(pco2_3days, by=c("hadm_id","extubation_time"))

pco2_mean_compare %>% 
  view()

#PCO2_3days에서 데이터를 유니온하자

pco2_24 <- pco2_check %>%
  filter(pco2_to_Extubation_hour <= 24 & pco2_to_Extubation_hour>=0) %>% 
  group_by(hadm_id,extubation_time) %>% 
  mutate(pco24 = mean(pco2)) %>% 
  ungroup() %>%
  select("hadm_id","extubation_time","pco24") %>% 
  rename("pco2"="pco24")
  distinct()
  

pco2_24 %>% 
  count()
#2623

pco2_re1<- pco2_24 %>% 
  union(pco2_3days)

pco2_re1 %>% 
  count()

write.csv(pco2_re1, "D:/Projects/MIMIC3_EXTRACT_R/pco2_re1.csv") #home

#----------------------------------------------------------------------------------------------


  
F1_pco2 <- pco22 %>% 
    left_join(pco23, by = c("hadm_id", "extubation_time")) %>% 
    select("hadm_id","extubation_time","pco12","pco24","pco2unit.y") %>% 
    rename("pco2unit" = "pco2unit.y") %>% 
    distinct() %>% 
    compute(dbplyr::in_schema("public","F1_pco2"), temporary = FALSE, overwrite = TRUE)

F1_pco2 
