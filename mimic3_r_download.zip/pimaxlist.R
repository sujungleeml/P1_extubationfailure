#------ Pimax(Peak insp.Pressure) -------------------------

items = c(224695)
ext_chartevents(items)


Pimaxlist <- ext_chartevents(items) %>% 
  rename("pimaxtime" = "charttime","pimax"="valuenum","pimaxunit"="valueuom") %>% 
  select("hadm_id", "pimaxtime", "pimax","pimaxunit") %>% 
  compute(dbplyr::in_schema("public","Pimaxlist"), temporary = FALSE, overwrite = TRUE)

