
#--------543 -- PlateauPressure-----------------------------

items = c(543)
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

PlatPreslist <- ext_chartevents(items) %>% 
  rename("platprestime" = "charttime","platpres"="valuenum","platpresunit"="valueuom") %>% 
  select("hadm_id", "platprestime", "platpres","platpresunit") %>% 
  compute(dbplyr::in_schema("public","PlatPreslist"), temporary = FALSE, overwrite = TRUE)
