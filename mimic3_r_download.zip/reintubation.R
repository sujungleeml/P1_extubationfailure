# Y 변수는...
# Extubation 하고 intubation 다시 하면 이건 reintubation 이다. intubation time>extubationtime 면 reintubation 이라고 할 수 있다.
# Extubation farilure 는 extubation 후 48 시간 이내 재삽관(intubation) 한 것이다
# 
# 순서는 intubation -> extubation ->intubation ->extubation 등으로 한 환자의 한 입원당 여러번 수행 될 수 있다.
# 그러므로, extubation 후 가장 가까운 intubation 건을 찾아야 한다. (동시시간인 경우가 과거에 있어서. 확인이 필요하다.)
# & Extubation_to_Intubation_time <= 48

int <- procedureevents_mv %>% 
  filter(itemid %in% c(224385)) %>%
  rename("intubation_time"="starttime") %>% 
  select("hadm_id","intubation_time","orderid","statusdescription", "cancelreason") %>% 
  filter(tolower(statusdescription) != "rewritten")

ext<- procedureevents_mv %>% 
  filter(itemid %in% c(227194)) %>%
  rename("extubation_time"="starttime") %>% 
  select("hadm_id","extubation_time","orderid","statusdescription", "cancelreason") %>% 
  filter(tolower(statusdescription) != "rewritten") 

inextime <- ext %>% 
  left_join(int, by=("hadm_id"))

inextime

inex1 <- inextime %>% 
  mutate(Extubation_to_Intubation_time = hour(intubation_time -extubation_time)) %>% #extubation 하고 intubation 까지 몇시간이 걸렸냐 = intu - extu 
  mutate(reintubation_time = if_else(Extubation_to_Intubation_time >= 0 , intubation_time, NULL)) %>% 
  select("hadm_id","intubation_time","orderid.x", "extubation_time","orderid.y","reintubation_time","Extubation_to_Intubation_time") %>% 
  filter(!is.na(intubation_time)) 
    
reintu1 = inex1 %>% 
  filter(extubation_time != intubation_time) %>% 
  filter(Extubation_to_Intubation_time >= 0)
    
lastintu = inex1 %>% 
  filter(extubation_time > intubation_time ) %>% 
  filter(extubation_time != intubation_time) %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(intubation_time), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) 

D = union(reintu1, lastintu) 
  
  
count(A) # 9953건
count(B) # 5093건 intubation 없는 extubation 제거거
count(C) # 4260건 "rewritten제거"
count(D) # 3901건 (extubation = intubation 인 데이터 제거함함)

extubationtime <- D %>%
  mutate(extubation_failure = if_else((Extubation_to_Intubation_time >=0 &Extubation_to_Intubation_time <=48),1,0)) %>% 
  select("hadm_id","intubation_time","extubation_time","reintubation_time","Extubation_to_Intubation_time","extubation_failure") %>% 
  compute(dbplyr::in_schema("public","extubationtime"), temporary = FALSE, overwrite = TRUE)
  
  
  

##intubation 잘못뽑음 : itemid 418(데이터없음) = intubation _date 
##intubation :224385 :  extubation_date 182(데이터없음)
#일단 extubation_to_intubation 이 음수다 = reintubation 이벤트가 없었다
# =완전히 extubation 했다고 해석할 수 있다
# = 성공으로 볼 수 있다
# 오키이..
# 그리고 extubation_to_intubationtime 이 양수다
# =reintubation을 했다
# =얼마만에 했는지에 따라 성공과 실패
# =48시간 이내에 reintu하면 실패, 아니면 성공
# ㅋㅋㅋㅋㅋㅋㅋㅋㅋ
# 그럼 성공과 실패를 확인하는
# 컬럼 하나 추가필요