
#--------High/Low/Peak/Mean/Neg insp force ("RespPressure")-----------------------------

items = c(218,436,535,444,459,224697,224695,224696,224746,224747 )
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

ResPreslist <- ext_chartevents(items) %>% 
  rename("resprestime" = "charttime","respres"="valuenum","respresunit"="valueuom") %>% 
  select("hadm_id", "resprestime", "respres","respresunit") %>% 
  compute(dbplyr::in_schema("public","ResPreslist"), temporary = FALSE, overwrite = TRUE)
