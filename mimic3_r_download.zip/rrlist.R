# when itemid in (51,442,455,6701,220179,220050) and valuenum > 0 and valuenum < 400 then 2 -- SysBP
# when itemid in (8368,8440,8441,8555,220180,220051) and valuenum > 0 and valuenum < 300 then 3 -- DiasBP




# # when itemid in (615,618,220210,224690) and valuenum > 0 and valuenum < 70 then 5 -- RespRate-----------------------------

items = c(615,618,220210,224690)
ext_chartevents(items)

RRlist <- ext_chartevents(items) %>% 
  rename("rrtime" = "charttime","rr"="valuenum","rrunit"="valueuom") %>% 
  select("hadm_id", "rrtime", "rr","rrunit") %>% 
  compute(dbplyr::in_schema("public","RRlist"), temporary = FALSE, overwrite = TRUE)

RRlist
 