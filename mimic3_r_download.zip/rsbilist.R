#-----  RSBI  --------------------------------------------------------------------------------------------
extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public", "extubationtime"))
items = c(224740.644,595,1397)


RSBIlist <- ext_chartevents(items) %>% 
  rename("rsbitime" = "charttime","rsbi"="valuenum","rsbiunit"="valueuom") %>% 
  select("hadm_id", "rsbitime", "rsbi","rsbiunit") %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > rsbitime ) %>% 
  select("hadm_id","extubation_time", "rsbitime","rsbi","rsbiunit") %>% 
  mutate(RSBI_to_Extubation_hour = day(extubation_time-rsbitime)*24+hour(extubation_time-rsbitime)) %>% 
  compute(dbplyr::in_schema("public","RSBIlist"), temporary = FALSE, overwrite = TRUE)


#RSBI -> extubation time이 NA임 : extubation 을 시행하지 않았으므로 대상자가 아님. 삭제
#extubation_time>RSBItime  extubation 전에 시행한 것만 필요 
#RSBI3 = RSBI2 %>% 
#  filter(RSBI_to_Extubation_hour <= 72)
#RSBI3 #RSBI는 시간을 안정하고 봐야 할듯.... 시간으로 자르면 작아짐??????????????????