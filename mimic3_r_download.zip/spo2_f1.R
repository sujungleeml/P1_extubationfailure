## -- SPO2, peripheral-------------------------------------------------------------------------

extubationtime <- dplyr::tbl(conn, dbplyr::in_schema("public","extubationtime"))
Spo2list <- dplyr::tbl(conn, dbplyr::in_schema("public","Spo2list"))

Spo2list

SpO2_f1 <- Spo2list %>% 
  left_join(extubationtime, by = c("hadm_id"), 'copy' = TRUE) %>% 
  filter(!is.na(extubation_time)) %>% 
  filter(extubation_time > spo2time ) %>% 
  mutate(Spo2_to_Extubation_hour = day(extubation_time-spo2time)*24+hour(extubation_time-spo2time)) %>% 
  select("hadm_id","extubation_time","spo2","spo2time","Spo2_to_Extubation_hour") %>% 
  group_by(hadm_id, extubation_time) %>% 
  arrange(desc(spo2time), .by_group =TRUE) %>% 
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  compute(dbplyr::in_schema("public","SpO2_f1"), temporary = FALSE, overwrite = TRUE)
