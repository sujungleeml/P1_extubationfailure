## -- SPO2, peripheral
# 646, 220277

##chartevents
items = c(646, 220277)
Spo2list <- ext_chartevents(items) %>% 
  rename("spo2time" = "charttime", "spo2" = "valuenum") %>% 
  select("hadm_id","spo2time","spo2") %>% 
  compute(dbplyr::in_schema("public","Spo2list"), temporary = FALSE, overwrite = TRUE)

