
library(dplyr)
library(DBI)
library(readr)
library(dbplyr)
library(stringr)
library(readr)
library(tidyverse)
library(vroom)
library(lubridate)
library(dbplot)
library(skimr)
library(ggplot2)

data <- read_csv("dataset6_dropna.csv")

#Extubaion failure = 1,Extubation non-failure = 0
data %>% 
  filter(extubation_failure == 1) %>% 
  filter(gender == 0) %>% 
  count()

532/215 #2.474419

#female = 1, male = 0
data %>% 
  filter(extubation_failure == 1) %>% 
  skim() 
