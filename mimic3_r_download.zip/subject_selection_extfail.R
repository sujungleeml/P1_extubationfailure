# Extubation 하고 intubation 다시 하면 이건 reintubation 이다.
# intubation time > extubationtime 면 reintubation 이라고 할 수 있다.
# Extubation farilure 는 extubation 후 48 시간 이내 재삽관(intubation) 한 것이다
# 
# 순서는 intubation -> extubation ->intubation ->extubation 등으로 한 환자의 한 입원당 여러번 수행 될 수 있다.
# 그러므로, extubation 후 가장 가까운 intubation 건을 찾아야 한다. (동시시간인 경우가 과거에 있어서. 확인이 필요하다.)
# & Extubation_to_Intubation_time < 48

# 한 환자의 한 입원당 여러번의 extubation 이벤트가 발생할 수 있다.
# intubation~extubation 까지 걸린 시간 = Ventilator_duration 을 구한다.
# ventilator_duration >= 24 일것.
# hadim_id 중 가장 처음 있었던 extubation event 를 추출해야 한다.


procedureevents_mv <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "procedureevents_mv"))

#Intubation event 추출하기
int <- procedureevents_mv %>% 
  filter(itemid %in% c(224385)) %>%
  rename("intubation_time"="starttime") %>% 
  select("hadm_id","intubation_time","orderid","statusdescription", "cancelreason") %>% 
  filter(tolower(statusdescription) != "rewritten")

#Extubation event 추출하기기
ext<- procedureevents_mv %>% 
  filter(itemid %in% c(227194)) %>%
  rename("extubation_time"="starttime") %>% 
  select("hadm_id","extubation_time","orderid","statusdescription", "cancelreason") %>% 
  filter(tolower(statusdescription) != "rewritten") 

#left 조인하여 extubation 옆에 intubation 을 붙이고 reintubation 계산하기
inextime <- ext %>% 
  left_join(int, by=("hadm_id"))

inextime

inex1 <- inextime %>% 
  mutate(Extubation_to_Intubation_time = day(extubation_time-intubation_time)*24+hour(intubation_time -extubation_time)) %>% #extubation 하고 intubation 까지 몇시간이 걸렸냐 = intu - extu 
  mutate(reintubation_time = if_else(Extubation_to_Intubation_time >= 0 , intubation_time, NULL)) %>% 
  mutate(ventilator_duration_hour = day(extubation_time-intubation_time)*24+hour(extubation_time-intubation_time)) %>% 
  select("hadm_id","intubation_time","orderid.x", "extubation_time","orderid.y","reintubation_time","ventilator_duration_hour","Extubation_to_Intubation_time") %>% 
  filter(!is.na(intubation_time)) %>% 
  filter(intubation_time < extubation_time)

inex1 %>% 
  count() #3214
inex1 %>% 
  view()

inex1 %>% 
  filter(ventilator_duration_hour < 24) %>% 
  count() #1120

inex1 %>% 
  filter(ventilator_duration_hour>=24) %>% 
  count() #2094

inex2 <- inex1 %>% 
  filter(ventilator_duration_hour >=24)

inex2 %>% view()

## reintubation 건을 찾습니다.--------------------
inex2 %>% 
  filter(!is.na(reintubation_time)) %>% 
  count()

reintu1 <- inex2 %>% 
  filter(!is.na(reintubation_time))
## reintubation = 2094 건 모든 대상자가 reintubation 시행함 -------------------------



# subject1 = 한 대상자의 같은 입원일에 여러 이벤트가 발생해도 다 포함

subject1 = inex2 %>% 
  mutate(Extubation_Failure = if_else(Extubation_to_Intubation_time >0 & Extubation_to_Intubation_time < 48,1,0)) %>% #Failure = 1, non-failure = 0 
  compute(dbplyr::in_schema("public","subject1"), temporary = FALSE, overwrite = TRUE)

subject1 %>% 
  count(Extubation_Failure ==1)
# non-failure = 1303, failure = 791 

#2094

#subject2 = 같은 방문에서 여러 이벤트가 생길 때 가장 늦게 수행한 intubation 건만 

subject2 = inex2 %>% 
  filter(extubation_time > intubation_time) %>% #extubation 이 intubation 다음에 와야함! 
  filter(extubation_time != intubation_time) %>% #그리고 같지 않은거(발생할 수 없는 이벤트트)
  group_by(hadm_id, extubation_time) %>% #hadm_id와 extubation time 이 같은 것 중에 (같은 extubation event에서)
  arrange(desc(intubation_time), .by_group =TRUE) %>% #가장 늦게 수행한 intubation 건?
  mutate(n=row_number()) %>% 
  filter(n==1) %>% 
  ungroup() %>% 
  mutate(Extubation_Failure = if_else(Extubation_to_Intubation_time >0 & Extubation_to_Intubation_time < 48,1,0)) %>%  #Failure = 1, non-failure = 0
  compute(dbplyr::in_schema("public","subject2"), temporary = FALSE, overwrite = TRUE) 


subject2 %>% 
  count() #1712 명

subject2 %>% 
  count(Extubation_Failure ==1)
#non-failure = 969, failure =743




# 
# lastintu %>% 
#   count()
# 
# lastintu %>% 
#   view()
# 
# ##2734 건
# 
# # 
# # 
# # D = union(reintu1, lastintu) 
# 
# 
# D %>% 
#   filter(extubation_time > intubation_time) %>% 
#   mutate()
#   group_by(hadm_id) %>% 
#   arrange(extubation_time, .by_group = TRUE) %>% 
#   mutate(n2=row_number()) %>% 
#   view()
# 
# count(A) # 9953건
# count(B) # 5093건 intubation 없는 extubation 제거거
# count(C) # 4260건 "rewritten제거"
# count(D) # 3901건 (extubation = intubation 인 데이터 제거함함)
# 
# extubationtime <- D %>%
#   mutate(extubation_failure = if_else((Extubation_to_Intubation_time >=0 &Extubation_to_Intubation_time <=48),1,0)) %>% 
#   select("hadm_id","intubation_time","extubation_time","reintubation_time","Extubation_to_Intubation_time","extubation_failure") %>% 
#   compute(dbplyr::in_schema("public","extubationtime"), temporary = FALSE, overwrite = TRUE)