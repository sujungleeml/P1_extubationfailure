#-------- Ve : exhaled minute volume 분당 호기량 1분동안 전달되는 공기의 총량 L/min -----------------------------

# 445, 448, 449, 450, 1340, 1486, 1600, 224687 -- minute volume
items = c(445, 448, 449, 450, 650, 1010, 1102, 1323, 1340, 1486, 1600, 224687, 1380, 1724, 1664, 2319)
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

Velist <- ext_chartevents(items) %>% 
  rename("vetime" = "charttime","ve"="valuenum","Veunit"="valueuom") %>% 
  select("hadm_id", "vetime", "ve","Veunit") %>% 
  compute(dbplyr::in_schema("public","Velist"), temporary = FALSE, overwrite = TRUE)

