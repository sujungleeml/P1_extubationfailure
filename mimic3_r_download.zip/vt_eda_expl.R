

# Vt3_2 %>% 
#   filter(vt > 5000)
# 
# Vt3_2 %>% 
#   filter(vt != 0) %>% 
#   filter(vt != 6000) %>% 
#   filter(vt != 1) %>% 
#   filter(hadm_id == 102667)
# 
# Vt3_2 %>% 
#   filter(vt != 0) %>% 
#   filter(vt != 6000) %>% 
#   filter(vt != 1) %>% 
#   filter(hadm_id == 142899) %>% 
#   slice(20:40)
# 
# Vt3_2 %>% 
#   filter(vt != 0) %>% 
#   filter(vt != 6000) %>% 
#   filter(vt != 1) %>% 
#   filter(hadm_id == 195925) %>% 
#   slice(1:20)
# 
# Vt3_2 %>% 
#   filter(hadm_id == 170587) %>% 
#   filter(vttime > as_datetime("2162-10-15 22:50:00"))
# 
# Vt3_2 %>% 
#   filter(hadm_id == 170587) %>% 
#   with(hist(vt))

Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt < 3000 & vt >=1000) # vt가 1000이상 3000미만은 471개 였다.

TA2 = Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt < 6000) %>% 
  filter(vt < 3000 & vt >=2000) # vt가 2000이상 3000미만은 43개 였다.

B = Vt3_2 %>% 
  filter(vt != 0) %>% 
  filter(vt != 1) %>% 
  filter(vt < 6000) %>% 
  filter(hadm_id %in% TA2$hadm_id)

TA2
view(B)
#같은시간에 12와 2060대 함께 있음 
#50-2000의 값만 남기고 전부 없애버리기

Vt3_2 %>%
  filter(vt >= 50) %>% 
  filter(vt <= 2000) %>% 
  with(hist(vt))

# Tidal volume initial set 값 (기계상)
#그다음 봐야 할 것 = 같은 날짜 같은 시간에 다른데이터



Vt3_3 = Vt3_2 %>%
  filter(vt >= 50) %>% 
  filter(vt <= 2000)

Vt3_3

Vt3_4<- Vt3_3 %>% 
  group_by(hadm_id, extubation_time, vttime)
distinct()

Vt3_4 %>% 
  add_count(hadm_id, extubation_time, vttime) %>% 
  filter(n >= 2) %>% 
  with(hist(n))

Vt3_4 %>% 
  add_count(hadm_id, extubation_time, vttime) %>% 
  filter(n ==2) %>%
  ungroup() %>% 
  distinct(hadm_id)

#hadm_id, extubation_time, vttime 이 같고 vt 값이 다른 케이스에 대하여 확인하였고
#최대 12개까지 중복된 시간에 다른값이 기재되어 있었다. 대부분의 대상자는 비슷한 값 범위내였으나, 몇몇 환자에서 400,800 과같은 큰 차이가 관찰되었다.
#어떤 값이 정확한 값인지 알 수 없고, 환자의 이상치를 대변할 수 있다고 생각되어
#hadm_id, extubation_time, vttime 이 같고 vt 값이 다른 케이스는 평균을 내어 1개의 값으로 대체하였다.


Vt24 <- Vt3_4 %>% 
  group_by(hadm_id, extubation_time) %>% 
  mutate(mean_vt24 = mean(vt)) %>% 
  select(hadm_id, extubation_time, mean_vt24, vtunit) %>% 
  distinct()

Vt24

Vt12 <- Vt3_4 %>% 
  filter(Vt_to_Extubation_hour <= 12) %>% 
  group_by(hadm_id, extubation_time) %>% 
  summarise(mean_vt12 = mean(vt))

Vt12

Vt_f1 <- Vt24 %>% 
  left_join(Vt12, by = c("hadm_id", "extubation_time")) %>% 
  select(hadm_id, extubation_time, mean_vt24, mean_vt12, vtunit)

Vt_f1
Vt_f1 =  Vt_f1 %>% 
  compute(dbplyr::in_schema("public","Vt_f1"), temporary = FALSE, overwrite = TRUE)

#?count
#  mutate(mean_pimax24 = mean(pimax, na.rm = TRUE)) %>% 
#  select(hadm_id, extubation_time, mean_pimax24, pimaxunit) %>% 
#  distinct()


