chartevents_1 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_1"))
chartevents_2 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_2"))
chartevents_3 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_3"))
chartevents_4 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_4"))
chartevents_5 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_5"))
chartevents_6 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_6"))
chartevents_7 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_7"))
chartevents_8 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_8"))
chartevents_9 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_9"))
chartevents_10 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_10"))
chartevents_11 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_11"))
chartevents_12 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_12"))
chartevents_13 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_13"))
chartevents_14 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_14"))
chartevents_15 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_15"))
chartevents_16 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_16"))
chartevents_17 <- dplyr::tbl(conn, dbplyr::in_schema("mimic3", "chartevents_17"))


#-------- V(te) :Tidal volume 1 회 호흡 시 전달되는 공기의 양 (정상 성인기준 400-500 ml)-----------------------------

items = c(639, 654, 681, 682, 683, 684,224685,224684,224686, 24009)
ext_chartevents(items)

#chartevents 말고 다른데도 있을까? Procedure _mv/?

Vtlist<- ext_chartevents(items) %>% 
  rename("vttime" = "charttime","vt"="valuenum","vtunit"="valueuom") %>% 
  compute(dbplyr::in_schema("public","Vtlist"), temporary = FALSE, overwrite = TRUE)

count(Vtlist)
Vtlist <- Vtlist %>% 
  filter(error != 1)


F1_Vt <- dplyr::tbl(conn, dbplyr::in_schema("public", "F1_Vt"))
F1_Vt %>% 
  count()

